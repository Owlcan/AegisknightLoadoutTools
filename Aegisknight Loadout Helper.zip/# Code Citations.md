# Code Citations

## License: MIT
https://github.com/mendhak/mendhak.github.io/blob/a0775ebfd5cfc6c7e529728ff2a7b4467ff6b106/posts/2024-03-24-kobo-text-to-images-with-stable-diffusion.md

```
.

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1
```


## License: unknown
https://github.com/FlashOTFR/rpg-character-sheet/blob/9aa275108fecf7b33d7f85ae1e45c9970529064c/views/layouts/main.handlebars

```
.

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1
```


## License: MIT
https://github.com/Canadianfaller7/project2-dnd-generator/blob/1344c10fd921cda23a5d4ebbe0824f9cc93afb79/views/layouts/main.handlebars

```
.

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1
```


## License: MIT
https://github.com/mendhak/mendhak.github.io/blob/a0775ebfd5cfc6c7e529728ff2a7b4467ff6b106/posts/2024-03-24-kobo-text-to-images-with-stable-diffusion.md

```
.

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>D&D Character Generator</title>
    <link rel="stylesheet" href="
```


## License: unknown
https://github.com/FlashOTFR/rpg-character-sheet/blob/9aa275108fecf7b33d7f85ae1e45c9970529064c/views/layouts/main.handlebars

```
.

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>D&D Character Generator</title>
    <link rel="stylesheet" href="
```


## License: MIT
https://github.com/Canadianfaller7/project2-dnd-generator/blob/1344c10fd921cda23a5d4ebbe0824f9cc93afb79/views/layouts/main.handlebars

```
.

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>D&D Character Generator</title>
    <link rel="stylesheet" href="
```

