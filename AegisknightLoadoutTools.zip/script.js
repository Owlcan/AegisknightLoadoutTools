// Armor data
const armorData = {
    // Helmet options
    "Hypersensory-Scanner-Array": {
        name: "Hypersensory Scanner Array",
        description: "This advanced helmet is a marvel of sensory enchantment, merging arcane optics with practical battlefield awareness. Grants darkvision and the ability to detect invisible creatures.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/hyperscannerarray.png",
        progression: [
            "<strong>Level 1:</strong> Darkvision (60 ft.) and Basic Sensor that highlights hidden or invisible creatures.",
            "<strong>Level 4:</strong> Enhanced Detection Mode reveals invisible creatures within 30 ft. for 1 minute (once per short rest).",
            "<strong>Level 7:</strong> Truesight Activation grants Truesight out to 30 ft. for 1 minute (once per short rest).",
            "<strong>Level 11:</strong> Investigative Augmentation adds advantage on Investigation checks to find illusions or hidden entities.",
            "<strong>Level 14:</strong> Augmented Sensory Overload increases Truesight range to 60 ft. and detects magical auras within 30 ft."
        ]
    },    "Neuroprotective-Casement": {
        name: "Neuroprotective Casement",
        description: "A sleek, rune-etched helmet designed to shield your mind from intrusive psychic assaults. Provides enhanced mental fortification and psychic resistance.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/neuroprotectivecasement.png",
        progression: [
            "<strong>Level 1:</strong> +1 bonus to AC and slight resistance to psychic damage.",
            "<strong>Level 4:</strong> Advantage on saving throws against charm effects.",
            "<strong>Level 7:</strong> Immunity to the frightened condition.",
            "<strong>Level 11:</strong> Immunity to charm effects and resistance to force damage.",
            "<strong>Level 14:</strong> Immunity to psychic damage and advantage on Intelligence saving throws."
        ]
    },    "Ultimate-Bastion-Heavy-Helmet": {
        name: "Ultimate-Bastion Heavy Helmet",
        description: "Forged in the crucible of relentless combat and imbued with archaic defensive runes, this helmet provides formidable protection against multiple damage types.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/ultimatebastion.png",
        progression: [
            "<strong>Level 1:</strong> +1 bonus to AC and resistance to radiant damage.",
            "<strong>Level 4:</strong> Resistance to necrotic damage.",
            "<strong>Level 7:</strong> Immunity to radiant damage.",
            "<strong>Level 11:</strong> Additional +1 bonus to AC (total +2) and resistance/immunity to one chosen damage type.",
            "<strong>Level 14:</strong> Immunity to necrotic damage and advantage on saving throws against spells."
        ]
    },    "Golden-Chain-Hood": {
        name: "Golden Chain Hood",
        description: "A majestic hood interwoven with shimmering golden chains that pulse with divine energy, offering enhanced divine abilities and protection.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/holygoldchain.png",
        progression: [
            "<strong>Level 1:</strong> +1 bonus to AC and saving throws against charm effects, darkvision (60 ft.), and detect magic ability.",
            "<strong>Level 4:</strong> Enhanced scanning mode for invisible or ethereal creatures.",
            "<strong>Level 7:</strong> +1 bonus to Wisdom saving throws and advantage on charm/fear saves.",
            "<strong>Level 11:</strong> Radiant Feedback deals extra radiant damage after using detection abilities.",
            "<strong>Level 14:</strong> Divine Ascendance grants Truesight, advantage on Wisdom saves, and bonus radiant damage."
        ]
    },    "Oracles-Tongue-Helm": {
        name: "Oracle's Tongue Helm",
        description: "Unlocks the power of language, allowing you to speak, read, and write a multitude of tongues while bridging the gap between mortals and spirits.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/oraclestongue.png",
        progression: [
            "<strong>Level 1:</strong> Two additional languages, Comprehend Languages ability, and +1 bonus to Persuasion checks.",
            "<strong>Level 4:</strong> Learn an additional language and cast Speak with Animals once per short rest.",
            "<strong>Level 7:</strong> Automatically decipher simple texts in any language and initiate telepathic conversations.",
            "<strong>Level 11:</strong> Permanent +1 bonus to Persuasion checks and cast Tongues once per long rest.",
            "<strong>Level 14:</strong> Universal Oratory ability that makes all creatures understand your words."
        ]
    },    "Pacifier-Themed-Helmet": {
        name: "Pacifier of Quietude",
        description: "A pacifier-themed helmet designed for caster-builds who value quiet spellcasting and mental focus over brute protection.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/pacifierofquietude.png",
        progression: [
            "<strong>Level 1:</strong> Silent Spellcasting negates verbal components and short-range telepathy (30 ft.).",
            "<strong>Level 4:</strong> Mutes ambient noise, granting advantage on Concentration checks in loud environments.",
            "<strong>Level 7:</strong> Enhanced telepathy (60 ft.) and nonverbal spell components can be dispensed with.",
            "<strong>Level 11:</strong> Mind shield allows re-rolling failed Wisdom saves against psychic effects once per short rest.",
            "<strong>Level 14:</strong> Silent casting becomes nearly undetectable, requiring DC 15 Perception to notice."
        ]
    },    "Bonnet-Themed-Helmet": {
        name: "Bonnet of Blushing Bravado",
        description: "For those who'd rather charm than conceal, this ostentatiously babyish bonnet radiates an irresistible level of adorable absurdity that distracts everyone around it.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/bonnetsallet.png",
        progression: [
            "<strong>Level 1:</strong> +1 bonus to Charisma and advantage on Persuasion checks.",
            "<strong>Level 4:</strong> Aura of adorable charm forces Charisma checks to maintain composure.",
            "<strong>Level 7:</strong> Allies within 10 ft. gain advantage on saving throws against fear.",
            "<strong>Level 11:</strong> Additional +1 bonus to saving throws against fear, charm, and 'soiling' effects for nearby allies.",
            "<strong>Level 14:</strong> 'Potty Parade' ability incapacitates creatures with uncontrollable mirth once per long rest."
        ]
    },    // Pauldrons options
    "Exultant-Type": {
        name: "Exultant Type",
        description: "Designed for the charismatic and commanding presence on the battlefield, these pauldrons enhance your social prowess and influence allies.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/exultantpauldrons.png",
        progression: [
            "<strong>Level 1:</strong> +1 to Persuasion or Intimidation checks.",
            "<strong>Level 4:</strong> Allies within 10 ft. gain advantage on saving throws against charm effects.",
            "<strong>Level 7:</strong> Double proficiency bonus on Persuasion or Intimidation checks.",
            "<strong>Level 11:</strong> Allies within 10 ft. receive +1 bonus to Charisma saving throws.",
            "<strong>Level 14:</strong> Charisma score increases by 2 (max 22)."
        ]
    },    "Vanguard-Heavy-Type": {
        name: "Vanguard Heavy Type",
        description: "For Aegisknights who demand unwavering durability, these pauldrons provide formidable protection while absorbing and deflecting incoming damage.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/vanguardheavypauldrons.png",
        progression: [
            "<strong>Level 1:</strong> +2 bonus to AC and resistance to nonmagical damage.",
            "<strong>Level 4:</strong> Resistance to two damage types of your choice.",
            "<strong>Level 7:</strong> Once per short rest, use reaction to halve incoming damage.",
            "<strong>Level 11:</strong> Immunity to one of your chosen damage types.",
            "<strong>Level 14:</strong> Resistance to all damage types except psychic."
        ]
    },    "Tech-Type": {
        name: "Tech Type",
        description: "Engineered for versatility and precision, these pauldrons integrate advanced mechanized components to support technical and tactical needs.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/techpauldrons.png",
        progression: [
            "<strong>Level 1:</strong> Proficiency in one extra tool and two robotic arms granting +5 bonus to crafting actions.",
            "<strong>Level 4:</strong> Advantage on Strength (Athletics) checks for grappling.",
            "<strong>Level 7:</strong> Proficiency in an additional tool of your choice.",
            "<strong>Level 11:</strong> Ability to manipulate two objects in one turn.",
            "<strong>Level 14:</strong> Use the Help action as a bonus action."
        ]
    },    "Marksman-Type-Pauldron": {
        name: "Marksman Type Pauldron",
        description: "Engineered for ranged specialists, optimized for precise targeting and rapid missile deployment with versatile ammunition options.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/marksmanpauldrons.png",
        progression: [
            "<strong>Level 1:</strong> Sharp Shooter feature and mounted missile launcher with explosion damage.",
            "<strong>Level 4:</strong> Additional use of Sharp Shooter feature daily.",
            "<strong>Level 7:</strong> Increased explosion damage and barrage fires 4 darts instead of 3.",
            "<strong>Level 11:</strong> +2 bonus to ranged attack rolls for 1 minute once per short rest.",
            "<strong>Level 14:</strong> Advantage on one ranged attack roll per turn when using Sharp Shooter."
        ]
    },    "Kinetic-Resonance-Pauldron": {
        name: "Kinetic Resonance Pauldron",
        description: "Pulses with raw kinetic energy of movement, turning dashing into a storehouse of explosive force for both defense and offense.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/kineticresonancepauldrons.png",
        progression: [
            "<strong>Level 1:</strong> +2 bonus to Athletics and Acrobatics, store Kinetic Charges when dashing.",
            "<strong>Level 4:</strong> Advantage on Dexterity saving throws when moving half your speed.",
            "<strong>Level 7:</strong> Kinetic Charges deal extra 1d8 force damage and push targets.",
            "<strong>Level 11:</strong> Reaction to deal 2d8 force damage to attackers and gain +2 AC.",
            "<strong>Level 14:</strong> Double movement speed and deal bonus force damage after dashing."
        ]
    },    "Diaper-Duty-Pauldrons": {
        name: "Diaper Duty Pauldrons",
        description: "Adorned with adorable embroidered swaddles, cartoonish bibs, and tiny pacifiers, these pauldrons capture the nurturing chaos of diaper school, protecting you with a refreshing burst of cleanliness.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/diaperdutypauldrons.png",
        progression: [
            "<strong>Level 1:</strong> Basic abilities include nurturing abilities and cleansing effects.",
            "<strong>Level 4:</strong> Enhanced cleaning magic and protection against 'soiling' effects.",
            "<strong>Level 7:</strong> Diaper Dash allows standing up and extra movement without opportunity attacks.",
            "<strong>Level 11:</strong> Clean Sweep Counter forces strength saving throws on attackers, potentially reducing their movement.",
            "<strong>Level 14:</strong> Ultimate upgrade provides advanced nurturing and protective capabilities."
        ]
    },

    // Chest armor options    
        "Balanced-Type-Composite-Frame": {
        name: "Balanced Type Composite Frame",
        hitdice: "d10",
        armorclass: "14+ Dex modifier (max +2)",
        description: "A balanced chest armor that provides moderate protection and mobility with an energy shield.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/balancedarmor.png",
        progression: [
            "<strong>Level 1:</strong> AC 14 + Dex modifier (max +2) and temporary +2 shield bonus to AC for 1 minute once per day.",
            "<strong>Level 4:</strong> Resistance to one damage type for 1 minute once per short rest.",
            "<strong>Level 7:</strong> +2 bonus to initiative rolls.",
            "<strong>Level 11:</strong> Enhanced shield bonus of +4 AC instead of +2.",
            "<strong>Level 14:</strong> Immunity to one chosen damage type."
        ]
    },  
        "Bulwark-Type-Frame": {
        name: "Bulwark Type Frame",
        hitdice: "d12",
        armorclass: "17",
        description: "Embodying steadfast resilience, this chestpiece sacrifices nimbleness for solid defense and damage negation.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/bulwark.png",
        progression: [
            "<strong>Level 1:</strong> AC 17, Bulwark Aegis negates one damage type for 1 minute once per day, d12 hit die.",
            "<strong>Level 4:</strong> Bulwark Aegis can be used twice per day.",
            "<strong>Level 7:</strong> Passive resistance to two chosen damage types.",
            "<strong>Level 11:</strong> Critical hits reduced to normal hits during Bulwark Aegis.",
            "<strong>Level 14:</strong> Resistance to all damage types except psychic."
        ]
    },
        "Light-Type-Frame": {
        name: "Light Type Frame",
        hitdice: "d8",
        armorclass: "13 + Dex modifier",
        description: "Maximizes mobility at the expense of heavy armor, designed for agile Aegisknights who prioritize speed and dexterity.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/lighttypearmor.png",
        progression: [
            "<strong>Level 1:</strong> Lower base AC, +15 ft. movement speed, +1 bonus to AC from energy field, d8 hit die.",
            "<strong>Level 4:</strong> Additional +10 ft. movement speed (total +25 ft.).",
            "<strong>Level 7:</strong> Advantage on Dexterity saving throws.",
            "<strong>Level 11:</strong> Immunity to being restrained or grappled.",
            "<strong>Level 14:</strong> Dash as a bonus action without provoking opportunity attacks once per short rest."
        ]
    },
        "Xtra-Hev-Composite-Frame": {
        name: "Xtra-Hev Composite Frame",
        hitdice: "d10",
        armorclass: "16",
        description: "A heavy-duty frame with regenerating energy shield and enhanced defensive capabilities.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/xtrahevarmor.png",
        progression: [
            "<strong>Level 1:</strong> d10 hit die, AC 16, +1 to Constitution saves, Regen Shield grants temporary hit points.",
            "<strong>Level 4:</strong> AC increases to 17, shield regenerates 4 temporary hit points per turn.",
            "<strong>Level 7:</strong> +2 bonus to Constitution checks and increased shield capacity.",
            "<strong>Level 11:</strong> Additional shield regeneration and effective AC of 18 with full shield.",
            "<strong>Level 14:</strong> Fortress Mode increases shield capacity by 50% and reduces incoming damage."
        ]
    },
    "Soiling-Shield-Bib": {
        name: "Soiling Shield Bib",
        description: "This oversized, magically enchanted bib is designed to ward off the filth and chaos of the battlefield, ensuring that no matter how messy the combat gets, you remain pristine.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/soilingshieldbib.png",
        progression: [
            "<strong>Level 1:</strong> Advantage on checks/saves against 'soiling' effects, base AC of 14 + Dex modifier (max +3).",
            "<strong>Level 4:</strong> Gain resistance to poison damage and immunity to disease.",
            "<strong>Level 7:</strong> Generate a cleansing aura that grants nearby allies advantage on saves against poison.",
            "<strong>Level 11:</strong> Purifying Strike adds radiant damage to attacks against 'corrupted' enemies.",
            "<strong>Level 14:</strong> Perfect Purity grants immunity to poison damage and the poisoned condition."
        ]
    },

    // Arms/Gloves options    
       "Shadestreak-Handmantles": {
        name: "Shadestreak Handmantles",
        description: "Dexterity-focused gauntlets designed for finesse and subtlety, providing lock-bypassing abilities and enhanced stealth.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/shadestreak.png",
        progression: [
            "<strong>Level 1:</strong> Proficiency with thieves' tools and ability to bypass locks once per day.",
            "<strong>Level 4:</strong> Advantage on Sleight of Hand checks.",
            "<strong>Level 7:</strong> Disarm traps without triggering them once per short rest.",
            "<strong>Level 11:</strong> Cast Invisibility on yourself once per short rest.",
            "<strong>Level 14:</strong> Bypass magical locks once per long rest."
        ]
    },
    "Blastbreaker-Fists": {
        name: "Blastbreaker Fists",
        description: "Engineered for raw melee power, enhancing physical might and allowing easier wielding of larger weapons.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/blastbreakers",
        progression: [
            "<strong>Level 1:</strong> Advantage on strength checks, +1 to melee damage, treat two-handed weapons as one-handed.",
            "<strong>Level 4:</strong> +2 bonus to melee attack rolls.",
            "<strong>Level 7:</strong> Extra 1d8 force damage once per turn on a hit.",
            "<strong>Level 11:</strong> Grapple two creatures at once, deals 1d6 damage to grappled creatures.",
            "<strong>Level 14:</strong> Ignore nonmagical damage resistance, extra 2d8 force damage on criticals."
        ]
    },"Somatic-Satellites": {
        name: "Somatic Satellites",
        description: "Floating magical spheres that can be launched as ranged attacks or used to store spells for later use.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/somaticsatellites.png",
        progression: [
            "<strong>Level 1:</strong> Spheres deal 1d8 force damage or store spells for later use.",
            "<strong>Level 4:</strong> Increase to 3 satellites.",
            "<strong>Level 7:</strong> Stored spells can be cast as reactions, store Counterspell once per day.",
            "<strong>Level 11:</strong> Deliver touch spells at 30 ft. range.",
            "<strong>Level 14:</strong> Gain a fourth satellite, stored spells last until cast."
        ]
    },"Serene-Palm-Gauntlets": {
        name: "Serene Palm Gauntlets",
        description: "Imbued with the essence of martial arts, allowing defense and controlled offense with elegant strikes.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/serenepalm.png",
        progression: [
            "<strong>Level 1:</strong> Parry Reflex reduces damage by 1d4 + proficiency bonus, +1 AC against melee attacks.",
            "<strong>Level 4:</strong> Force disadvantage on ranged attacks once per short rest, Parry Reflex improved to 1d6.",
            "<strong>Level 7:</strong> Open Palm Strike deals 1d6 force damage and pushes targets back.",
            "<strong>Level 11:</strong> Counterattack after successful Parry Reflex, improved Open Palm Strike.",
            "<strong>Level 14:</strong> Zen Reversal completely negates an attack and counters with 2d8 force damage."
        ]
    },
    "Infantile-Mittens": {
        name: "Infantile Mittens",
        description: "These gauntlets feature oversized, cuddly mittens that limit fine dexterity but grant unique protective benefits.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/infantilemitts.png",
        progression: [
            "<strong>Level 1:</strong> Inelegant Grip imposes penalty on Dexterity tasks but grants immunity to touch-based traps and poisons, advantage on saves against curses from touching objects.",
            "<strong>Level 4:</strong> Increase unarmed strike damage by 1d4.",
            "<strong>Level 7:</strong> Advantage on Strength (Athletics) checks for grappling or shoving.",
            "<strong>Level 11:</strong> Additional bonus to Strength checks for physical tasks.",
            "<strong>Level 14:</strong> Gain one-time bonus to any Strength-based contest per short rest, automatically winning."
        ]
    },    // Boots options
    "Ultra-Duty-Boots": {
        name: "Ultra-Duty Boots",
        description: "Built for the stalwart warrior who refuses to be knocked off balance, these boots anchor you to the ground.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/ultradutyboots.png",
        progression: [
            "<strong>Level 1:</strong> Advantage on saves against knockback/prone, but -5 ft. movement speed (25 ft. total).",
            "<strong>Level 4:</strong> Immunity to knockback effects.",
            "<strong>Level 7:</strong> Advantage on saving throws against being knocked prone.",
            "<strong>Level 11:</strong> Stand up from prone without using movement.",
            "<strong>Level 14:</strong> +5 bonus to saves against forced movement."
        ]
    },    "Balanced-Boots": {
        name: "Balanced Boots",
        description: "Sleek, streamlined boots that enhance speed and nimbleness while helping you navigate tricky terrain.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/balanced%20boots.png",
        progression: [
            "<strong>Level 1:</strong> +5 ft. movement speed (35 ft. total) and advantage on saves against trip attacks.",
            "<strong>Level 4:</strong> Ignore the effects of difficult terrain.",
            "<strong>Level 7:</strong> Additional +10 ft. movement speed (45 ft. total).",
            "<strong>Level 11:</strong> Advantage on saves against speed reduction effects.",
            "<strong>Level 14:</strong> Move across vertical surfaces and liquids without falling."
        ]
    },    "Blastcore-Soles": {
        name: "Blastcore Soles",
        description: "Infuse your steps with volatile energy for explosive speed and gravity-defying leaps that catch foes off guard.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/blastcoresoles.png",
        progression: [
            "<strong>Level 1:</strong> 40 ft. movement speed from explosive propulsion.",
            "<strong>Level 4:</strong> 25% increased jump distance and advantage on jump checks with running start.",
            "<strong>Level 7:</strong> Leap over enemies without provoking opportunity attacks once per short rest.",
            "<strong>Level 11:</strong> Leap up to 60 ft. horizontally or 30 ft. vertically.",
            "<strong>Level 14:</strong> Immunity to fall damage and create shockwaves dealing 2d10 force damage on landing."
        ]
    },    "Virtues-Bastion": {
        name: "Virtue's Bastion (Diaper Cover)",
        description: "This enchanted diaper cover isn't merely lower-wear—it's a full-body safeguard for those who must don the bulkiest, most efficient aegisknight diapers. Integrated with a magical self‑cleaning booster, the cover continuously sanitizes, deodorizes, and refreshes your diaper area, allowing you to navigate treacherous, trap‑laden grounds without penalty and always look, feel, and smell immaculate.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/virtuesbastion.png",
        progression: [
            "<strong>Level 1:</strong> Diaper Mastery Activation grants improved mobility, +1 bonus on saving throws against traps, and automatic cleansing of minor soiling.",
            "<strong>Level 4:</strong> Advanced Cleansing Burst grants advantage on hygiene checks and increases trap safety bonus to +2.",
            "<strong>Level 7:</strong> Continuous Cleanliness makes Diaper Mastery benefits permanent without requiring Fuel Cell expenditure.",
            "<strong>Level 11:</strong> Rapid Refresh allows extra movement without opportunity attacks and temporary saving throw bonus once per short rest.",
            "<strong>Level 14:</strong> Ultimate Diaper Time-Out creates aura of pristine cleanliness that negates traps and can incapacitate enemies."
        ]
    },    "Ethereal-Stride-Boots": {
        name: "Ethereal Stride Boots",
        description: "These sleek, mystically enhanced boots bear subtle, luminescent runes that channel arcane energy into your step. They are designed for rapid, unhindered movement—and pair especially well with raiment that lacks synergy. The runes spark with kinetic vigor as you dash across the battlefield.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/etherealstride.png",
        progression: [
            "<strong>Level 1:</strong> Enhanced Mobility increases walking speed by +5 ft. (40 ft. total). Difficult Terrain Negation allows treating difficult terrain as normal once per short rest.",
            "<strong>Level 4:</strong> Runic Surge grants advantage on Acrobatics checks to avoid hazards and traps for 1 minute once per short rest.",
            "<strong>Level 7:</strong> Resonant Stride adds 1d6 force damage to next melee attack after taking the Dash action.",
            "<strong>Level 11:</strong> Mystic Shift allows teleporting up to 15 ft. without provoking opportunity attacks once per short rest.",
            "<strong>Level 14:</strong> Ethereal Ascension grants invisibility to nonmagical sight and ability to pass through obstacles for 1 round once per long rest."
        ]
    },

    // Raiment options    
        "Photonic-Cape": {
        name: "Photonic Cape",
        description: "A high-tech cloak suffused with prismatic energy, allowing you to harness light and shadow for defense and stealth.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/photoniccape.png",
        progression: [
            "<strong>Level 3:</strong> Cast Shield multiple times per day, Displacement effect once per day, +2 bonus on Stealth checks.",
            "<strong>Level 6:</strong> Invisibility for 1 minute and flying speed of 30 ft. for 30 minutes once per short rest.",
            "<strong>Level 8:</strong> Resistance to radiant and necrotic damage.",
            "<strong>Level 12:</strong> Immunity to radiant damage and teleport 60 ft. as a bonus action once per short rest."
        ]
    },    
        "Soul-Core-Manifold": {
        name: "Soul Core Manifold",
        description: "A core of elemental power granting bonus Cell Charges and elemental rebuke capabilities.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/soulcoremanifold.png",
        progression: [
            "<strong>Level 3:</strong> Two extra Cell Charges, cast Hellish Rebuke, enhanced recharge rate.",
            "<strong>Level 6:</strong> Resistance to your chosen elemental type.",
            "<strong>Level 8:</strong> Deal 2d8 elemental damage to melee attackers.",
            "<strong>Level 12:</strong> Immunity to your chosen element and reaction-based shield."
        ]
    },
    "Godhead-Shard": {
        name: "Godhead Shard",
        description: "A radiant fragment of divine essence infusing your raiment with celestial power and spellcasting.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/godheadshard.png",
        progression: [
            "<strong>Level 3:</strong> Two divine cantrips and one 1st-level divine spell, second-highest Cell Charge pool, restore charges via Religion checks.",
            "<strong>Level 6:</strong> Additional divine spell slot.",
            "<strong>Level 8:</strong> Integrate a cleric subclass feature into your armor.",
            "<strong>Level 12:</strong> Cast Divine Word once per long rest and enhanced Cell Charge restoration."
        ]
    },
    "Arcanomatrix": {
        name: "Arcanomatrix",
        description: "A nexus of arcane energy woven into your raiment, granting spellcasting abilities and magical defenses.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/arcanomatrix.png",
        progression: [
            "<strong>Level 3:</strong> Two arcane cantrips and one 1st-level arcane spell, extra Cell Charges for spells.",
            "<strong>Level 6:</strong> Integrate a wizard subclass feature.",
            "<strong>Level 8:</strong> Cast Counterspell once per long rest without expending Cell Charges.",
            "<strong>Level 12:</strong> Resistance to force damage and advantage on saves against spells."
        ]
    },
    "Luminant-Engine": {
        name: "Luminant Engine",
        description: "A radiant marvel channeling ephemeral power of illumination into tangible effects like light bolts and barriers.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/luminantengine.png",
        progression: [
            "<strong>Level 3:</strong> Causal Points for luminancer-like abilities, enhanced energy reservoir.",
            "<strong>Level 6:</strong> Luminal Motion teleport once per short rest.",
            "<strong>Level 8:</strong> Resistance to radiant and necrotic damage.",
            "<strong>Level 12:</strong> Immunity to radiant damage and unleash a Causal Nova once per long rest."
        ]
    },
    "Mystery-Module": {
        name: "Mystery Module",
        description: "A wild card raiment with effects determined by rolls on a custom table, offering unpredictable benefits.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/mysterymodule.png",
        progression: [
            "<strong>Level 3:</strong> Random baseline effect from DM table and stable bonus like damage immunity or AC bonus.",
            "<strong>Level 6:</strong> Additional random ability from DM table.",
            "<strong>Level 8:</strong> Reality-bending special action, like forcing enemy rerolls.",
            "<strong>Level 12:</strong> Major distinguishing ability that redefines your battlefield role."
        ]
    },
    "Transmorphic-Belt": {
        name: "Transmorphic Belt",
        description: "The Shapeshifter's Cinch grants elemental resistance, breath weapons, and size-altering capabilities.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/transformationbelt.png",
        progression: [
            "<strong>Level 3:</strong> Resistance to one elemental damage type, breath weapon, and size increase to Large.",
            "<strong>Level 6:</strong> Enhanced breath weapon damage and extended transformation duration.",
            "<strong>Level 8:</strong> Second elemental variant for breath weapon and improved elemental resistance.",
            "<strong>Level 12:</strong> Boost speed and Strength during transformation."
        ]
    },    "Unstable-Fury-Core": {
        name: "Unstable Fury Core",
        description: "A volatile engine of primal might transforming aggression into destructive power with overload risks.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/unstablefurycore.png",
        progression: [
            "<strong>Level 3:</strong> Fury Mode grants bonus damage and temporary hit points, but with overload risk and extra charge costs.",
            "<strong>Level 6:</strong> Focused Smash for devastating strikes that bypass resistances.",
            "<strong>Level 8:</strong> Temporary resistance to physical damage and reduced misfire chance.",
            "<strong>Level 12:</strong> Fury Unleashed deals massive force damage and can stun targets."
        ]
    },
    "Diaper-Daycare-Raiment": {
        name: "Diaper Daycare Raiment",
        description: "Harnessing the wholesome chaos of Diaper School, this raiment transforms your suit's central core into a beacon of nurturing mischief and disruptive battleflow.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/daycarecore.png",
        progression: [
            "<strong>Level 3:</strong> Soothing Miracle grants advantage on fear saves, Absorbent Shield reduces damage, and Diaper Douse Blast can immobilize enemies.",
            "<strong>Level 4:</strong> Soothing Miracle can be used an extra time per short rest.",
            "<strong>Level 7:</strong> Diaper Dash allows bonus action movement without opportunity attacks.",
            "<strong>Level 11:</strong> Clean Sweep Counter splashes cleansing liquid at attackers, potentially reducing their movement.",
            "<strong>Level 14:</strong> Advanced nurturing abilities with greater range and effectiveness."
        ]
    },
    "Mephidium-Coda": {
        name: "Mephidium Coda (Skunk's Tail)",
        description: "Embodying toxic misfortune and grimy power, the Mephidium Coda transforms your battle presence into a malodorous curse that intensifies with combat grime.",
        imageUrl: "https://ik.imagekit.io/owlcan/aegisknight/mephidiumcoda.png",
        progression: [
            "<strong>Level 3:</strong> Base toxic abilities including poison effects and noxious aura.",
            "<strong>Level 6:</strong> Enhanced poison damage and expanded aura of misfortune.",
            "<strong>Level 9:</strong> Additional toxic effects with chance to inflict special conditions.",
            "<strong>Level 12:</strong> Ultimate stinking cloud ability and toxic immunity."
        ]
    }
};

// Hardcoded subset of weapons data
const weaponsData = [
    {
        "id": "club",
        "name": "Club",
        "damage_dice": "1d4",
        "damage_type": "bludgeoning",
        "light": true,
        "finesse": false,
        "special": null,
        "category": "simple melee",
        "weight": 2,
        "cost": "1 sp"
    },
    {
        "id": "dagger",
        "name": "Dagger",
        "damage_dice": "1d4",
        "damage_type": "piercing",
        "light": true,
        "finesse": true,
        "special": "Thrown (range 20/60)",
        "category": "simple melee",
        "weight": 1,
        "cost": "2 gp"
    },
    {
        "id": "greatclub",
        "name": "Greatclub",
        "damage_dice": "1d8",
        "damage_type": "bludgeoning",
        "light": false,
        "finesse": false,
        "special": "Two-handed",
        "category": "simple melee",
        "weight": 10,
        "cost": "2 sp"
    },
    {
        "id": "handaxe",
        "name": "Handaxe",
        "damage_dice": "1d6",
        "damage_type": "slashing",
        "light": true,
        "finesse": false,
        "special": "Thrown (range 20/60)",
        "category": "simple melee",
        "weight": 2,
        "cost": "5 gp"
    },
    {
        "id": "javelin",
        "name": "Javelin",
        "damage_dice": "1d6",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Thrown (range 30/120)",
        "category": "simple melee",
        "weight": 2,
        "cost": "5 sp"
    },
    {
        "id": "light_hammer",
        "name": "Light Hammer",
        "damage_dice": "1d4",
        "damage_type": "bludgeoning",
        "light": true,
        "finesse": false,
        "special": "Thrown (range 20/60)",
        "category": "simple melee",
        "weight": 2,
        "cost": "2 gp"
    },
    {
        "id": "mace",
        "name": "Mace",
        "damage_dice": "1d6",
        "damage_type": "bludgeoning",
        "light": false,
        "finesse": false,
        "special": null,
        "category": "simple melee",
        "weight": 4,
        "cost": "5 gp"
    },
    {
        "id": "quarterstaff",
        "name": "Quarterstaff",
        "damage_dice": "1d6",
        "damage_type": "bludgeoning",
        "light": false,
        "finesse": false,
        "special": "Versatile (1d8)",
        "category": "simple melee",
        "weight": 4,
        "cost": "2 sp"
    },
    {
        "id": "sickle",
        "name": "Sickle",
        "damage_dice": "1d4",
        "damage_type": "slashing",
        "light": true,
        "finesse": false,
        "special": null,
        "category": "simple melee",
        "weight": 2,
        "cost": "1 gp"
    },
    {
        "id": "spear",
        "name": "Spear",
        "damage_dice": "1d6",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Thrown (range 20/60), versatile (1d8)",
        "category": "simple melee",
        "weight": 3,
        "cost": "1 gp"
    },
    {
        "id": "light_crossbow",
        "name": "Light Crossbow",
        "damage_dice": "1d8",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 80/320), loading, two-handed",
        "category": "simple ranged",
        "weight": 5,
        "cost": "25 gp"
    },
    {
        "id": "dart",
        "name": "Dart",
        "damage_dice": "1d4",
        "damage_type": "piercing",
        "light": false,
        "finesse": true,
        "special": "Thrown (range 20/60)",
        "category": "simple ranged",
        "weight": 0.25,
        "cost": "5 cp"
    },
    {
        "id": "shortbow",
        "name": "Shortbow",
        "damage_dice": "1d6",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 80/320), two-handed",
        "category": "simple ranged",
        "weight": 2,
        "cost": "25 gp"
    },
    {
        "id": "sling",
        "name": "Sling",
        "damage_dice": "1d4",
        "damage_type": "bludgeoning",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 30/120)",
        "category": "simple ranged",
        "weight": 0,
        "cost": "1 sp"
    },
    {
        "id": "battleaxe",
        "name": "Battleaxe",
        "damage_dice": "1d8",
        "damage_type": "slashing",
        "light": false,
        "finesse": false,
        "special": "Versatile (1d10)",
        "category": "martial melee",
        "weight": 4,
        "cost": "10 gp"
    },
    {
        "id": "flail",
        "name": "Flail",
        "damage_dice": "1d8",
        "damage_type": "bludgeoning",
        "light": false,
        "finesse": false,
        "special": null,
        "category": "martial melee",
        "weight": 2,
        "cost": "10 gp"
    },
    {
        "id": "glaive",
        "name": "Glaive",
        "damage_dice": "1d10",
        "damage_type": "slashing",
        "light": false,
        "finesse": false,
        "special": "Heavy, reach, two-handed",
        "category": "martial melee",
        "weight": 6,
        "cost": "20 gp"
    },
    {
        "id": "greataxe",
        "name": "Greataxe",
        "damage_dice": "1d12",
        "damage_type": "slashing",
        "light": false,
        "finesse": false,
        "special": "Heavy, two-handed",
        "category": "martial melee",
        "weight": 7,
        "cost": "30 gp"
    },
    {
        "id": "greatsword",
        "name": "Greatsword",
        "damage_dice": "2d6",
        "damage_type": "slashing",
        "light": false,
        "finesse": false,
        "special": "Heavy, two-handed",
        "category": "martial melee",
        "weight": 6,
        "cost": "50 gp"
    },
    {
        "id": "halberd",
        "name": "Halberd",
        "damage_dice": "1d10",
        "damage_type": "slashing",
        "light": false,
        "finesse": false,
        "special": "Heavy, reach, two-handed",
        "category": "martial melee",
        "weight": 6,
        "cost": "20 gp"
    },
    {
        "id": "lance",
        "name": "Lance",
        "damage_dice": "1d12",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Reach, special (disadvantage when attacking within 5 feet)",
        "category": "martial melee",
        "weight": 6,
        "cost": "10 gp"
    },
    {
        "id": "longsword",
        "name": "Longsword",
        "damage_dice": "1d8",
        "damage_type": "slashing",
        "light": false,
        "finesse": false,
        "special": "Versatile (1d10)",
        "category": "martial melee",
        "weight": 3,
        "cost": "15 gp"
    },
    {
        "id": "maul",
        "name": "Maul",
        "damage_dice": "2d6",
        "damage_type": "bludgeoning",
        "light": false,
        "finesse": false,
        "special": "Heavy, two-handed",
        "category": "martial melee",
        "weight": 10,
        "cost": "10 gp"
    },
    {
        "id": "morningstar",
        "name": "Morningstar",
        "damage_dice": "1d8",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": null,
        "category": "martial melee",
        "weight": 4,
        "cost": "15 gp"
    },
    {
        "id": "pike",
        "name": "Pike",
        "damage_dice": "1d10",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Heavy, reach, two-handed",
        "category": "martial melee",
        "weight": 18,
        "cost": "5 gp"
    },
    {
        "id": "rapier",
        "name": "Rapier",
        "damage_dice": "1d8",
        "damage_type": "piercing",
        "light": false,
        "finesse": true,
        "special": null,
        "category": "martial melee",
        "weight": 2,
        "cost": "25 gp"
    },
    {
        "id": "scimitar",
        "name": "Scimitar",
        "damage_dice": "1d6",
        "damage_type": "slashing",
        "light": true,
        "finesse": true,
        "special": null,
        "category": "martial melee",
        "weight": 3,
        "cost": "25 gp"
    },
    {
        "id": "shortsword",
        "name": "Shortsword",
        "damage_dice": "1d6",
        "damage_type": "piercing",
        "light": true,
        "finesse": true,
        "special": null,
        "category": "martial melee",
        "weight": 2,
        "cost": "10 gp"
    },
    {
        "id": "trident",
        "name": "Trident",
        "damage_dice": "1d6",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Thrown (range 20/60), versatile (1d8)",
        "category": "martial melee",
        "weight": 4,
        "cost": "5 gp"
    },
    {
        "id": "war_pick",
        "name": "War Pick",
        "damage_dice": "1d8",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": null,
        "category": "martial melee",
        "weight": 2,
        "cost": "5 gp"
    },
    {
        "id": "warhammer",
        "name": "Warhammer",
        "damage_dice": "1d8",
        "damage_type": "bludgeoning",
        "light": false,
        "finesse": false,
        "special": "Versatile (1d10)",
        "category": "martial melee",
        "weight": 2,
        "cost": "15 gp"
    },
    {
        "id": "whip",
        "name": "Whip",
        "damage_dice": "1d4",
        "damage_type": "slashing",
        "light": false,
        "finesse": true,
        "special": "Reach",
        "category": "martial melee",
        "weight": 3,
        "cost": "2 gp"
    },
    {
        "id": "hand_crossbow",
        "name": "Hand Crossbow",
        "damage_dice": "1d6",
        "damage_type": "piercing",
        "light": true,
        "finesse": false,
        "special": "Ammunition (range 30/120), light, loading",
        "category": "martial ranged",
        "weight": 3,
        "cost": "75 gp"
    },
    {
        "id": "heavy_crossbow",
        "name": "Heavy Crossbow",
        "damage_dice": "1d10",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 100/400), heavy, loading, two-handed",
        "category": "martial ranged",
        "weight": 18,
        "cost": "50 gp"
    },
    {
        "id": "longbow",
        "name": "Longbow",
        "damage_dice": "1d8",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 150/600), heavy, two-handed",
        "category": "martial ranged",
        "weight": 2,
        "cost": "50 gp"
    },
    {
        "id": "net",
        "name": "Net",
        "damage_dice": "0",
        "damage_type": "none",
        "light": false,
        "finesse": false,
        "special": "Special (restrain, one target), thrown (range 5/15)",
        "category": "martial ranged",
        "weight": 3,
        "cost": "1 gp"
    },
    {
        "id": "pistol",
        "name": "Pistol",
        "damage_dice": "1d10",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 30/90), loading, firearm",
        "category": "renaissance ranged",
        "weight": 3,
        "cost": "250 gp"
    },
    {
        "id": "musket",
        "name": "Musket",
        "damage_dice": "1d12",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 40/120), loading, two-handed, firearm",
        "category": "renaissance ranged",
        "weight": 10,
        "cost": "500 gp"
    },
    {
        "id": "blunderbuss",
        "name": "Blunderbuss",
        "damage_dice": "2d8",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 15/30), loading, two-handed, firearm, scatter",
        "category": "renaissance ranged",
        "weight": 10,
        "cost": "300 gp"
    },
    {
        "id": "pepperbox",
        "name": "Pepperbox",
        "damage_dice": "1d8",
        "damage_type": "piercing",
        "light": true,
        "finesse": false,
        "special": "Ammunition (range 30/90), firearm, reload (6)",
        "category": "renaissance ranged",
        "weight": 5,
        "cost": "450 gp"
    },
    {
        "id": "arquebus",
        "name": "Arquebus",
        "damage_dice": "1d12",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 50/150), loading, two-handed, firearm",
        "category": "renaissance ranged",
        "weight": 9,
        "cost": "450 gp"
    },
    {
        "id": "hand_mortar",
        "name": "Hand Mortar",
        "damage_dice": "2d8",
        "damage_type": "bludgeoning",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 30/90), explosive, reload (1), firearm",
        "category": "renaissance ranged",
        "weight": 10,
        "cost": "600 gp"
    },
    {
        "id": "revolver",
        "name": "Revolver",
        "damage_dice": "1d10",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 40/120), firearm, reload (6)",
        "category": "modern ranged",
        "weight": 3,
        "cost": "750 gp"
    },
    {
        "id": "shotgun",
        "name": "Shotgun",
        "damage_dice": "2d10",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 20/60), reload (2), two-handed, firearm, scatter",
        "category": "modern ranged",
        "weight": 7,
        "cost": "650 gp"
    },
    {
        "id": "double_barrel_shotgun",
        "name": "Double-Barrel Shotgun",
        "damage_dice": "2d10",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 20/60), reload (2), two-handed, firearm, scatter",
        "category": "modern ranged",
        "weight": 8,
        "cost": "850 gp"
    },
    {
        "id": "hunting_rifle",
        "name": "Hunting Rifle",
        "damage_dice": "2d10",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 80/240), reload (5), two-handed, firearm",
        "category": "modern ranged",
        "weight": 8,
        "cost": "700 gp"
    },
    {
        "id": "automatic_rifle",
        "name": "Automatic Rifle",
        "damage_dice": "2d8",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 80/240), reload (30), two-handed, firearm, burst fire",
        "category": "modern ranged",
        "weight": 8,
        "cost": "1000 gp"
    },
    {
        "id": "sniper_rifle",
        "name": "Sniper Rifle",
        "damage_dice": "2d12",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 150/600), reload (4), two-handed, firearm",
        "category": "modern ranged",
        "weight": 10,
        "cost": "1300 gp"
    },
    {
        "id": "grenade_launcher",
        "name": "Grenade Launcher",
        "damage_dice": "3d10",
        "damage_type": "bludgeoning",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 60/180), reload (1), two-handed, firearm, explosive",
        "category": "modern ranged",
        "weight": 12,
        "cost": "1500 gp"
    },
    {
        "id": "flamethrower",
        "name": "Flamethrower",
        "damage_dice": "3d6",
        "damage_type": "fire",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 15/30), energy, reload (5), two-handed, scatter, explosive",
        "category": "modern ranged",
        "weight": 15,
        "cost": "1200 gp"
    },
    {
        "id": "hand_cannon",
        "name": "Hand Cannon",
        "damage_dice": "2d12",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 20/60), reload (1), heavy, firearm",
        "category": "renaissance ranged",
        "weight": 8,
        "cost": "700 gp"
    },
    {
        "id": "laser_pistol",
        "name": "Laser Pistol",
        "damage_dice": "3d6",
        "damage_type": "fire",
        "light": true,
        "finesse": false,
        "special": "Ammunition (range 40/120), energy, reload (20)",
        "category": "futuristic ranged",
        "weight": 2,
        "cost": "2000 gp"
    },
    {
        "id": "laser_rifle",
        "name": "Laser Rifle",
        "damage_dice": "3d8",
        "damage_type": "fire",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 100/300), energy, reload (10), two-handed",
        "category": "futuristic ranged",
        "weight": 7,
        "cost": "2500 gp"
    },
    {
        "id": "plasma_pistol",
        "name": "Plasma Pistol",
        "damage_dice": "2d10",
        "damage_type": "fire",
        "light": true,
        "finesse": false,
        "special": "Ammunition (range 30/90), energy, reload (8)",
        "category": "futuristic ranged",
        "weight": 3,
        "cost": "2200 gp"
    },
    {
        "id": "plasma_rifle",
        "name": "Plasma Rifle",
        "damage_dice": "3d10",
        "damage_type": "fire",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 80/240), energy, reload (6), two-handed",
        "category": "futuristic ranged",
        "weight": 8,
        "cost": "3000 gp"
    },
    {
        "id": "plasma_launcher",
        "name": "Plasma Launcher",
        "damage_dice": "4d10",
        "damage_type": "fire",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 30/90), energy, reload (2), heavy, two-handed, explosive",
        "category": "futuristic ranged",
        "weight": 15,
        "cost": "3500 gp"
    },
    {
        "id": "gauss_rifle",
        "name": "Gauss Rifle",
        "damage_dice": "2d12",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 120/360), reload (5), heavy, two-handed, firearm",
        "category": "futuristic ranged",
        "weight": 12,
        "cost": "3200 gp"
    },
    {
        "id": "fusion_cannon",
        "name": "Fusion Cannon",
        "damage_dice": "6d6",
        "damage_type": "fire",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 60/180), energy, reload (1), heavy, two-handed, explosive",
        "category": "futuristic ranged",
        "weight": 20,
        "cost": "4000 gp"
    },
    {
        "id": "arc_blaster",
        "name": "Arc Blaster",
        "damage_dice": "4d6",
        "damage_type": "lightning",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 50/150), energy, reload (6), two-handed, chain (targets up to 3 creatures within 10 feet of each other)",
        "category": "futuristic ranged",
        "weight": 10,
        "cost": "3300 gp"
    },
    {
        "id": "sonic_disruptor",
        "name": "Sonic Disruptor",
        "damage_dice": "3d8",
        "damage_type": "thunder",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 40/120), energy, reload (4), two-handed, concussive (target must succeed on a Constitution save or be stunned until end of its next turn)",
        "category": "futuristic ranged",
        "weight": 8,
        "cost": "3100 gp"
    },
    {
        "id": "antimatter_rifle",
        "name": "Antimatter Rifle",
        "damage_dice": "6d12",
        "damage_type": "necrotic",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 120/360), energy, reload (2), heavy, two-handed",
        "category": "futuristic ranged",
        "weight": 15,
        "cost": "6000 gp"
    },
    {
        "id": "arcane_pistol",
        "name": "Arcane Pistol",
        "damage_dice": "1d10",
        "damage_type": "force",
        "light": true,
        "finesse": false,
        "special": "Ammunition (range 60/180), magic, firearm",
        "category": "magical ranged",
        "weight": 3,
        "cost": "800 gp"
    },
    {
        "id": "arcane_rifle",
        "name": "Arcane Rifle",
        "damage_dice": "2d8",
        "damage_type": "force",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 100/300), magic, reload (5), two-handed, firearm",
        "category": "magical ranged",
        "weight": 8,
        "cost": "1500 gp"
    },
    {
        "id": "arcane_launcher",
        "name": "Arcane Launcher",
        "damage_dice": "4d8",
        "damage_type": "force",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 50/150), reload (1), heavy, two-handed, magic, explosive",
        "category": "magical ranged",
        "weight": 15,
        "cost": "2500 gp"
    },
    {
        "id": "arcane_repeater",
        "name": "Arcane Repeater",
        "damage_dice": "1d8",
        "damage_type": "force",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 60/180), magic, reload (4), firearm",
        "category": "magical ranged",
        "weight": 5,
        "cost": "1000 gp"
    },
    {
        "id": "elemental_wand",
        "name": "Elemental Wand",
        "damage_dice": "3d6",
        "damage_type": "variable",
        "light": true,
        "finesse": true,
        "special": "Ammunition (range 60/180), magic, reload (7), versatile (user can choose between fire, cold, lightning, or acid damage)",
        "category": "magical ranged",
        "weight": 1,
        "cost": "1200 gp"
    },
    {
        "id": "eldritch_staff",
        "name": "Eldritch Staff",
        "damage_dice": "1d8",
        "damage_type": "bludgeoning",
        "light": false,
        "finesse": false,
        "special": "Versatile (1d10), magic (can also cast 3 cantrips)",
        "category": "magical melee",
        "weight": 4,
        "cost": "900 gp"
    },
    {
        "id": "crystal_focus_staff",
        "name": "Crystal Focus Staff",
        "damage_dice": "2d6",
        "damage_type": "force",
        "light": false,
        "finesse": false,
        "special": "Magic, versatile (2d8)",
        "category": "magical melee",
        "weight": 6,
        "cost": "1800 gp"
    },
    {
        "id": "force_cannon",
        "name": "Force Cannon",
        "damage_dice": "6d6",
        "damage_type": "force",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 60/180), reload (2), heavy, two-handed, magic, explosive",
        "category": "magical ranged",
        "weight": 12,
        "cost": "3500 gp"
    },
    {
        "id": "energy_whip",
        "name": "Energy Whip",
        "damage_dice": "2d6",
        "damage_type": "force",
        "light": true,
        "finesse": true,
        "special": "Reach, energy",
        "category": "magical melee",
        "weight": 3,
        "cost": "800 gp"
    },
    {
        "id": "plasma_blade",
        "name": "Plasma Blade",
        "damage_dice": "2d8",
        "damage_type": "fire",
        "light": true,
        "finesse": true,
        "special": "Energy",
        "category": "futuristic melee",
        "weight": 3,
        "cost": "1500 gp"
    },
    {
        "id": "vibro_sword",
        "name": "Vibro Sword",
        "damage_dice": "3d6",
        "damage_type": "slashing",
        "light": false,
        "finesse": true,
        "special": "Energy, versatile (3d8)",
        "category": "futuristic melee",
        "weight": 4,
        "cost": "1200 gp"
    },
    {
        "id": "gravity_hammer",
        "name": "Gravity Hammer",
        "damage_dice": "3d10",
        "damage_type": "bludgeoning",
        "light": false,
        "finesse": false,
        "special": "Heavy, two-handed, energy, concussive (targets within 10 feet must make a Strength save or be knocked prone)",
        "category": "futuristic melee",
        "weight": 15,
        "cost": "2500 gp"
    },
    {
        "id": "photon_glaive",
        "name": "Photon Glaive",
        "damage_dice": "2d10",
        "damage_type": "radiant",
        "light": false,
        "finesse": false,
        "special": "Reach, heavy, two-handed, energy",
        "category": "futuristic melee",
        "weight": 8,
        "cost": "1800 gp"
    },
    {
        "id": "wrist_blades",
        "name": "Wrist Blades",
        "damage_dice": "1d8",
        "damage_type": "slashing",
        "light": true,
        "finesse": true,
        "special": "Light, can be concealed, counts as unarmed strike",
        "category": "martial melee",
        "weight": 1,
        "cost": "400 gp"
    },
    {
        "id": "thermal_blade",
        "name": "Thermal Blade",
        "damage_dice": "1d8",
        "damage_type": "slashing",
        "light": true,
        "finesse": true,
        "special": "Light, deals additional 1d6 fire damage",
        "category": "futuristic melee",
        "weight": 2,
        "cost": "900 gp"
    },
    {
        "id": "quantum_dagger",
        "name": "Quantum Dagger",
        "damage_dice": "1d4",
        "damage_type": "piercing",
        "light": true,
        "finesse": true,
        "special": "Thrown (range 20/60), returns to wielder's hand after being thrown, energy, deals additional 1d6 force damage",
        "category": "futuristic melee",
        "weight": 1,
        "cost": "800 gp"
    },
    {
        "id": "chakram",
        "name": "Chakram",
        "damage_dice": "1d6",
        "damage_type": "slashing",
        "light": true,
        "finesse": true,
        "special": "Thrown (range 30/120), returns to wielder's hand on a successful hit",
        "category": "martial melee",
        "weight": 1,
        "cost": "50 gp"
    },
    {
        "id": "boomerang",
        "name": "Boomerang",
        "damage_dice": "1d4",
        "damage_type": "bludgeoning",
        "light": true,
        "finesse": true,
        "special": "Thrown (range 30/120), returns to wielder's hand on a miss",
        "category": "simple ranged",
        "weight": 1,
        "cost": "5 gp"
    },
    {
        "id": "kunai",
        "name": "Kunai",
        "damage_dice": "1d4",
        "damage_type": "piercing",
        "light": true,
        "finesse": true,
        "special": "Thrown (range 20/60), can be used as a climbing tool",
        "category": "simple melee",
        "weight": 0.5,
        "cost": "3 gp"
    },
    {
        "id": "repeating_crossbow",
        "name": "Repeating Crossbow",
        "damage_dice": "1d8",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 80/320), reload (5), two-handed",
        "category": "martial ranged",
        "weight": 7,
        "cost": "250 gp"
    },
    {
        "id": "exploding_bolts_crossbow",
        "name": "Exploding Bolts Crossbow",
        "damage_dice": "2d8",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 60/240), reload (3), two-handed, explosive",
        "category": "martial ranged",
        "weight": 9,
        "cost": "350 gp"
    },
    {
        "id": "hand_flintlock",
        "name": "Hand Flintlock",
        "damage_dice": "1d8",
        "damage_type": "piercing",
        "light": true,
        "finesse": false,
        "special": "Ammunition (range 40/120), loading, firearm",
        "category": "renaissance ranged",
        "weight": 2,
        "cost": "200 gp"
    },
    {
        "id": "flintlock_rifle",
        "name": "Flintlock Rifle",
        "damage_dice": "1d12",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 80/240), loading, two-handed, firearm",
        "category": "renaissance ranged",
        "weight": 10,
        "cost": "400 gp"
    },
    {
        "id": "bolt_action_rifle",
        "name": "Bolt-Action Rifle",
        "damage_dice": "2d10",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 120/360), reload (5), two-handed, firearm",
        "category": "modern ranged",
        "weight": 8,
        "cost": "800 gp"
    },
    {
        "id": "harpoon_gun",
        "name": "Harpoon Gun",
        "damage_dice": "1d10",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 30/120), reload (1), two-handed, tether",
        "category": "martial ranged",
        "weight": 8,
        "cost": "150 gp"
    },
    {
        "id": "heavy_repeating_crossbow",
        "name": "Heavy Repeating Crossbow",
        "damage_dice": "1d10",
        "damage_type": "piercing",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 100/400), reload (3), heavy, two-handed",
        "category": "martial ranged",
        "weight": 12,
        "cost": "350 gp"
    },
    {
        "id": "cannon",
        "name": "Cannon",
        "damage_dice": "8d10",
        "damage_type": "bludgeoning",
        "light": false,
        "finesse": false,
        "special": "Ammunition (range 120/480), reload (1), heavy, two-handed, explosive, firearm",
        "category": "renaissance ranged",
        "weight": 750,
        "cost": "1500 gp"
    },
    {
        "id": "cestus",
        "name": "Cestus",
        "damage_dice": "1d6",
        "damage_type": "bludgeoning",
        "light": true,
        "finesse": false,
        "special": "Light, counts as unarmed strike",
        "category": "martial melee",
        "weight": 1,
        "cost": "5 gp"
    },
    {
        "id": "scythe",
        "name": "Scythe",
        "damage_dice": "1d10",
        "damage_type": "slashing",
        "light": false,
        "finesse": false,
        "special": "Two-handed, reach",
        "category": "martial melee",
        "weight": 10,
        "cost": "20 gp"
    },
    {
        "id": "katana",
        "name": "Katana",
        "damage_dice": "1d8",
        "damage_type": "slashing",
        "light": false,
        "finesse": true,
        "special": "Versatile (1d10)",
        "category": "martial melee",
        "weight": 3,
        "cost": "50 gp"
    },
    {
        "id": "sai",
        "name": "Sai",
        "damage_dice": "1d4",
        "damage_type": "piercing",
        "light": true,
        "finesse": true,
        "special": "Light, special (can attempt to disarm as bonus action)",
        "category": "martial melee",
        "weight": 1,
        "cost": "10 gp"
    }
];

// Feats data
let featsData = [];
let selectedFeats = [];

// Load feats data directly to avoid CORS issues when running locally
document.addEventListener('DOMContentLoaded', function() {
    // Populate feats data from the hardcoded array
    featsData = [
    {
        "id": "ability_score_improvement",
        "name": "Ability Score Improvement",
        "description": "You can increase one ability score of your choice by 2, or you can increase two ability scores of your choice by 1. You can't use this feat to increase an ability score above 20.",
        "asi": true
    },
    {
        "id": "actor",
        "name": "Actor",
        "description": "Skilled at mimicry and dramatics, you gain the following benefits: Increase your Charisma score by 1, to a maximum of 20. You have advantage on Charisma (Deception) and Charisma (Performance) checks when trying to pass yourself off as a different person.",
        "asi": true
    },
    {
        "id": "athlete",
        "name": "Athlete",
        "description": "You gain the following benefits: Increase your Strength or Dexterity score by 1, to a maximum of 20. When you are prone, standing up uses only 5 feet of your movement. Climbing doesn't cost you extra movement. You can make a running long jump or high jump after only 5 feet of movement.",
        "asi": true
    },
    {
        "id": "charger",
        "name": "Charger",
        "description": "When you use your action to Dash, you can use a bonus action to make one melee weapon attack. If you move at least 10 feet in a straight line immediately before the attack, you either gain a +5 bonus to the attack's damage roll or push the target up to 10 feet away.",
        "asi": false
    },
    {
        "id": "crossbow_expert",
        "name": "Crossbow Expert",
        "description": "You gain the following benefits: You ignore the loading quality of crossbows with which you are proficient. Being within 5 feet of a hostile creature doesn't impose disadvantage on your ranged attack rolls. When you use the Attack action and attack with a one-handed weapon, you can use a bonus action to attack with a loaded hand crossbow you are holding.",
        "asi": false
    },
    {
        "id": "defensive_duelist",
        "name": "Defensive Duelist",
        "description": "When you are wielding a finesse weapon with which you are proficient and another creature hits you with a melee attack, you can use your reaction to add your proficiency bonus to your AC for that attack, potentially causing the attack to miss you.",
        "asi": false
    },
    {
        "id": "diaper_mastery",
        "name": "Diaper Mastery",
        "description": "Prerequisite: Incontinent flaw. Your Constitution score rises by 2 points. After consistent effort, training, or pure skill, you have conquered—most of—the hurdles of being in diapers 24/7 (or however time does or doesn't scale where you're at). Needless to say, you're in diapers for good—and they do quite a lot of good for you! Whenever you roll a 1 on a Potty Check or otherwise fill a diaper without leaking, you receive a +1 Relief Bonus to all rolls for 1 minute (10 rounds). Because of your time spent in and around diapers, you have advantage on Insight and Investigation checks related to diapers. You also have the newfound ability to track a diapered creature using the Survival skill—even if you are not trained in this skill. You no longer suffer many of the physical limitations of being diapered in combat. Only a Leaking Diaper will affect your combat ability. When diapered, you never suffer the Full Diaper or Messy Diaper status. You are adorably trustworthy when you stink. You have advantage on Persuasion checks when your diaper is messy—as long as this check is not intended to prove you are more mature than you look—or smell.",
        "asi": true
    },
    {
        "id": "dual_wielder",
        "name": "Dual Wielder",
        "description": "You master fighting with two weapons, gaining the following benefits: You gain a +1 bonus to AC while you are wielding a separate melee weapon in each hand. You can use two-weapon fighting even when the one-handed melee weapons you are wielding aren't light. You can draw or stow two one-handed weapons when you would normally be able to draw or stow only one.",
        "asi": false
    },
    {
        "id": "dungeon_delver",
        "name": "Dungeon Delver",
        "description": "Alert to the hidden traps and secret doors found in many dungeons, you gain the following benefits: You have advantage on Wisdom (Perception) and Intelligence (Investigation) checks made to detect the presence of secret doors. You have advantage on saving throws made to avoid or resist traps. You have resistance to the damage dealt by traps. You can search for traps while traveling at a normal pace.",
        "asi": false
    },
    {
        "id": "durable",
        "name": "Durable",
        "description": "Hardy and resilient, you gain the following benefits: Increase your Constitution score by 1, to a maximum of 20. When you roll a Hit Die to regain hit points, the minimum number of hit points you regain from the roll equals twice your Constitution modifier (minimum of 2).",
        "asi": true
    },
    {
        "id": "elemental_adept",
        "name": "Elemental Adept",
        "description": "Prerequisite: The ability to cast at least one spell. When you gain this feat, choose one of the following damage types: acid, cold, fire, lightning, or thunder. Spells you cast ignore resistance to damage of the chosen type. In addition, when you roll damage for a spell you cast that deals damage of that type, you can treat any 1 on a damage die as a 2. You can select this feat multiple times. Each time you do so, you must choose a different damage type.",
        "asi": false
    },
    {
        "id": "grappler",
        "name": "Grappler",
        "description": "Prerequisite: Strength 13 or higher. You've developed the skills necessary to hold your own in close-quarters grappling. You gain the following benefits: You have advantage on attack rolls against a creature you are grappling. You can use your action to try to pin a creature grappled by you. To do so, make another grapple check. If you succeed, you and the creature are both restrained until the grapple ends.",
        "asi": false
    },
    {
        "id": "great_weapon_master",
        "name": "Great Weapon Master",
        "description": "You've learned to put the weight of a weapon to your advantage, letting its momentum empower your strikes. You gain the following benefits: On your turn, when you score a critical hit with a melee weapon or reduce a creature to 0 hit points with one, you can make one melee weapon attack as a bonus action. Before you make a melee attack with a heavy weapon that you are proficient with, you can choose to take a -5 penalty to the attack roll. If the attack hits, you add +10 to the attack’s damage.",
        "asi": false
    },
    {
        "id": "healer",
        "name": "Healer",
        "description": "You are an able physician, allowing you to mend wounds quickly and get your allies back in the fight. You gain the following benefits: When you use a healer’s kit to stabilize a dying creature, that creature also regains 1 hit point. As an action, you can spend one use of a healer’s kit to tend to a creature and restore 1d6 + 4 hit points to it, plus additional hit points equal to the creature’s maximum number of Hit Dice. The creature can’t regain hit points from this feat again until it finishes a short or long rest.",
        "asi": false
    },
    {
        "id": "heavily_armored",
        "name": "Heavily Armored",
        "description": "Prerequisite: Proficiency with medium armor. You have trained to master the use of heavy armor, gaining the following benefits: Increase your Strength score by 1, to a maximum of 20. You gain proficiency with heavy armor.",
        "asi": true
    },
    {
        "id": "heavy_armor_master",
        "name": "Heavy Armor Master",
        "description": "Prerequisite: Proficiency with heavy armor. You can use your armor to deflect strikes that would kill others. You gain the following benefits: Increase your Strength score by 1, to a maximum of 20. While you are wearing heavy armor, bludgeoning, piercing, and slashing damage that you take from nonmagical weapons is reduced by 3.",
        "asi": true
    },
    {
        "id": "inspiring_leader",
        "name": "Inspiring Leader",
        "description": "Prerequisite: Charisma 13 or higher. You can spend 10 minutes inspiring your companions, shoring up their resolve to fight. When you do so, choose up to six friendly creatures (which can include yourself) within 30 feet of you who can see or hear you and who can understand you. Each creature gains temporary hit points equal to your level + your Charisma modifier. A creature can’t gain temporary hit points from this feat again until it has finished a short or long rest.",
        "asi": false
    },
    {
        "id": "keen_mind",
        "name": "Keen Mind",
        "description": "You have a mind that can track time, direction, and detail with uncanny precision. You gain the following benefits: Increase your Intelligence score by 1, to a maximum of 20. You always know which way is north. You always know the number of hours left before the next sunrise or sunset. You can accurately recall anything you have seen or heard within the past month.",
        "asi": true
    },
    {
        "id": "lightly_armored",
        "name": "Lightly Armored",
        "description": "You have trained to master the use of light armor, gaining the following benefits: Increase your Strength or Dexterity score by 1, to a maximum of 20. You gain proficiency with light armor.",
        "asi": true
    },
    {
        "id": "linguist",
        "name": "Linguist",
        "description": "You have studied languages and codes, gaining the following benefits: Increase your Intelligence score by 1, to a maximum of 20. You learn three languages of your choice. You can ably create written ciphers. Others can’t decipher a code you create unless you teach them, they succeed on an Intelligence (Investigation) check (DC equal to your Intelligence score + your proficiency bonus), or they use magic to decipher it.",
        "asi": true
    },
    {
        "id": "mobile",
        "name": "Mobile",
        "description": "You are exceptionally speedy and agile. You gain the following benefits: Your speed increases by 10 feet. When you use the Dash action, difficult terrain doesn’t cost you extra movement on that turn. When you make a melee attack against a creature, you don’t provoke opportunity attacks from that creature for the rest of the turn, whether you hit or not.",
        "asi": false
    },
    {
        "id": "moderately_armored",
        "name": "Moderately Armored",
        "description": "Prerequisite: Proficiency with light armor. You have trained to master the use of medium armor and shields, gaining the following benefits: Increase your Strength or Dexterity score by 1, to a maximum of 20. You gain proficiency with medium armor and shields.",
        "asi": true
    },
    {
        "id": "mounted_combatant",
        "name": "Mounted Combatant",
        "description": "You are a dangerous foe to face while mounted. While you are mounted and aren’t incapacitated, you gain the following benefits: You have advantage on melee attack rolls against any unmounted creature that is smaller than your mount. You can force an attack targeted at your mount to target you instead. If your mount is subjected to an effect that allows it to make a Dexterity saving throw to take only half damage, it instead takes no damage if it succeeds on the saving throw, and only half damage if it fails.",
        "asi": false
    },
    {
        "id": "observant",
        "name": "Observant",
        "description": "Quick to notice details of your environment, you gain the following benefits: Increase your Intelligence or Wisdom score by 1, to a maximum of 20. If you can see a creature’s mouth while it is speaking a language you understand, you can interpret what it’s saying by reading its lips. You have a +5 bonus to your passive Wisdom (Perception) and passive Intelligence (Investigation) scores.",
        "asi": true
    },
    {
        "id": "polearm_master",
        "name": "Polearm Master",
        "description": "You can keep your enemies at bay with reach weapons. You gain the following benefits: When you take the Attack action and attack with only a glaive, halberd, quarterstaff, or spear, you can use a bonus action to make a melee weapon attack with the opposite end of the weapon. This attack uses the same ability modifier as the primary attack. The weapon’s damage die for this attack is a d4. While you are wielding a glaive, halberd, pike, quarterstaff, or spear, other creatures provoke an opportunity attack from you when they enter your reach.",
        "asi": false
    },
    {
        "id": "resilient",
        "name": "Resilient",
        "description": "Choose one ability score. Increase the chosen ability score by 1, to a maximum of 20. You gain proficiency in saving throws using the chosen ability.",
        "asi": true
    },
    {
        "id": "ritual_caster",
        "name": "Ritual Caster",
        "description": "Prerequisite: Intelligence or Wisdom 13 or higher. You have learned a number of spells that you can cast as rituals. These spells are written in a ritual book, which you must have in hand while casting one of them. When you choose this feat, you acquire a ritual book holding two 1st-level spells of your choice. Choose one spellcasting class: bard, cleric, druid, sorcerer, warlock, or wizard. You must choose your spells from that class’s spell list, and the spells you choose must have the ritual tag. The class you choose also determines your spellcasting ability for these spells: Charisma for bard, sorcerer, or warlock; Wisdom for cleric or druid; or Intelligence for wizard.",
        "asi": false
    },
    {
        "id": "savage_attacker",
        "name": "Savage Attacker",
        "description": "Once per turn when you roll damage for a melee weapon attack, you can reroll the weapon’s damage dice and use either total.",
        "asi": false
    },
    {
        "id": "sentinel",
        "name": "Sentinel",
        "description": "You have mastered techniques to take advantage of every drop in any enemy’s guard, gaining the following benefits: When you hit a creature with an opportunity attack, the creature’s speed becomes 0 for the rest of the turn. Creatures within 5 feet of you provoke opportunity attacks from you even if they take the Disengage action before leaving your reach. When a creature within 5 feet of you makes an attack against a target other than you (and that target doesn’t have this feat), you can use your reaction to make a melee weapon attack against the attacking creature.",
        "asi": false
    },
    {
        "id": "sharpshooter",
        "name": "Sharpshooter",
        "description": "You have mastered ranged weapons and can make shots that others find impossible. You gain the following benefits: Attacking at long range doesn’t impose disadvantage on your ranged weapon attack rolls. Your ranged weapon attacks ignore half cover and three-quarters cover. Before you make an attack with a ranged weapon that you are proficient with, you can choose to take a -5 penalty to the attack roll. If the attack hits, you add +10 to the attack’s damage.",
        "asi": false
    },
    {
        "id": "shield_master",
        "name": "Shield Master",
        "description": "You use shields not just for protection but also for offense. You gain the following benefits while you are wielding a shield: If you take the Attack action on your turn, you can use a bonus action to try to shove a creature within 5 feet of you with your shield. If you aren’t incapacitated, you can add your shield’s AC bonus to any Dexterity saving throw you make against a spell or other harmful effect that targets only you. If you are subjected to an effect that allows you to make a Dexterity saving throw to take only half damage, you can use your reaction to take no damage if you succeed on the saving throw, interposing your shield between yourself and the source of the effect.",
        "asi": false
    },
    {
        "id": "skilled",
        "name": "Skilled",
        "description": "You gain proficiency in any combination of three skills or tools of your choice.",
        "asi": false
    },
    {
        "id": "skulker",
        "name": "Skulker",
        "description": "Prerequisite: Dexterity 13 or higher. You are expert at slinking through shadows. You gain the following benefits: You can try to hide when you are lightly obscured from the creature from which you are hiding. When you are hidden from a creature and miss it with a ranged weapon attack, making the attack doesn’t reveal your position. Dim light doesn’t impose disadvantage on your Wisdom (Perception) checks relying on sight.",
        "asi": false
    },
    {
        "id": "spell_sniper",
        "name": "Spell Sniper",
        "description": "Prerequisite: The ability to cast at least one spell. You have learned techniques to enhance your attacks with certain kinds of spells, gaining the following benefits: When you cast a spell that requires you to make an attack roll, the spell’s range is doubled. Your ranged spell attacks ignore half cover and three-quarters cover. You learn one cantrip that requires an attack roll. Choose the cantrip from the bard, cleric, druid, sorcerer, warlock, or wizard spell list. Your spellcasting ability for this cantrip depends on the spell list you chose: Charisma for bard, sorcerer, or warlock; Wisdom for cleric or druid; or Intelligence for wizard.",
        "asi": false
    },
    {
        "id": "tavern_brawler",
        "name": "Tavern Brawler",
        "description": "Accustomed to rough-and-tumble fighting using whatever weapons happen to be at hand, you gain the following benefits: Increase your Strength or Constitution score by 1, to a maximum of 20. You are proficient with improvised weapons. Your unarmed strike uses a d4 for damage. When you hit a creature with an unarmed strike or an improvised weapon on your turn, you can use a bonus action to attempt to grapple the target.",
        "asi": true
    },
    {
        "id": "tough",
        "name": "Tough",
        "description": "Your hit point maximum increases by an amount equal to twice your level when you gain this feat. Whenever you gain a level thereafter, your hit point maximum increases by an additional 2 hit points.",
        "asi": false
    },
    {
        "id": "war_caster",
        "name": "War Caster",
        "description": "Prerequisite: The ability to cast at least one spell. You have practiced casting spells in the midst of combat, learning techniques that grant you the following benefits: You have advantage on Constitution saving throws that you make to maintain your concentration on a spell when you take damage. You can perform the somatic components of spells even when you have weapons or a shield in one or both hands. When a hostile creature’s movement provokes an opportunity attack from you, you can use your reaction to cast a spell at the creature, rather than making an opportunity attack. The spell must have a casting time of 1 action and must target only that creature.",
        "asi": false
    },
    {
        "id": "weapon_master",
        "name": "Weapon Master",
        "description": "You have practiced extensively with a variety of weapons, gaining the following benefits: Increase your Strength or Dexterity score by 1, to a maximum of 20. You gain proficiency with four weapons of your choice.",
        "asi": true
    }
];
      // Initialize feats dropdown 
    populateFeatsDropdown();
    
    // Initialize weapons dropdowns
    populateWeaponDropdowns();
    
    // Add event listeners for large size weapon checkboxes
    document.getElementById('primary-large-size').addEventListener('change', function() {
        updateWeaponInfo('primary');
    });
    
    document.getElementById('secondary-large-size').addEventListener('change', function() {
        updateWeaponInfo('secondary');
    });
    
    // Initialize other feat-related elements
    initFeatsUI();
});

// Populate feats dropdown
function populateFeatsDropdown(searchTerm = '') {
    const featsSelect = document.getElementById('feats-select');
    
    // Clear existing options except the first one
    while (featsSelect.options.length > 1) {
        featsSelect.remove(1);
    }
    
    // Filter feats based on search term if provided
    const filteredFeats = searchTerm 
        ? featsData.filter(feat => 
            feat.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
            feat.description.toLowerCase().includes(searchTerm.toLowerCase()))
        : featsData;
      // Add feats to dropdown
    filteredFeats.forEach(feat => {
        const option = document.createElement('option');
        option.value = feat.id;
        option.textContent = feat.name + (feat.asi ? " (ASI)" : "");
        featsSelect.appendChild(option);
    });
}

// Functions
function updateArmorInfo(armorType) {
    const selectElement = document.getElementById(`${armorType}-select`);
    const selectedValue = selectElement.value;
    
    const nameElement = document.getElementById('selected-item-name');
    const descriptionElement = document.getElementById('selected-item-description');
    const imagePlaceholder = document.querySelector('.item-image-placeholder');
    
    if (selectedValue === "") {
        nameElement.textContent = "Select an armor piece";
        descriptionElement.textContent = "Information about the selected item will appear here.";
        imagePlaceholder.innerHTML = `<div class="placeholder-text">Image Placeholder</div>`;
        return;
    }
    
    const selectedArmor = armorData[selectedValue];
    nameElement.textContent = selectedArmor.name;
    
    // Update image if available
    if (selectedArmor.imageUrl) {
        imagePlaceholder.innerHTML = `<img src="${selectedArmor.imageUrl}" alt="${selectedArmor.name}" class="armor-image">`;
    } else {
        imagePlaceholder.innerHTML = `<div class="placeholder-text">Image Placeholder</div>`;
    }
    
    // Create a more detailed description with progression information
    let detailedDescription = `<p class="armor-description">${selectedArmor.description}</p>`;
    
    // Add chest armor specific details (Hit Die and AC)
    if (armorType === 'chest' && selectedArmor.hitdice && selectedArmor.armorclass) {
        const dexterityScore = document.getElementById('dexterity').value || 10;
        const constitutionScore = document.getElementById('constitution').value || 10;
        const dexModifier = getAbilityModifier(dexterityScore);
        const conModifier = getAbilityModifier(constitutionScore);
        
        const armorClass = calculateAC(selectedArmor.armorclass, dexterityScore);
        const maxHP = calculateMaxHP(selectedArmor.hitdice, constitutionScore);
        
        detailedDescription += `<div class="armor-stats">
            <p><strong>Hit Die:</strong> ${selectedArmor.hitdice}</p>
            <p><strong>Armor Class:</strong> ${selectedArmor.armorclass} (${armorClass} with DEX ${dexModifier >= 0 ? '+' : ''}${dexModifier})</p>
            <p><strong>Max HP at Level 5:</strong> ${maxHP} (with CON ${conModifier >= 0 ? '+' : ''}${conModifier})</p>
        </div>`;
    }
    
    detailedDescription += `<div class="armor-progression"><h4>Level Progression:</h4>`;
    
    selectedArmor.progression.forEach(prog => {
        detailedDescription += `<p>${prog}</p>`;
    });
    
    detailedDescription += `</div>`;
    descriptionElement.innerHTML = detailedDescription;
}

function finalizeLoadout() {
    const selectorContainer = document.querySelector('.selector-container');
    const loadoutResults = document.getElementById('loadout-results');
    
    // Hide selector, show results
    selectorContainer.style.display = 'none';
    loadoutResults.classList.remove('hidden');
    
    // Get ability scores
    const dexterityScore = document.getElementById('dexterity').value || 10;
    const constitutionScore = document.getElementById('constitution').value || 10;
    const strengthScore = document.getElementById('strength').value || 10; 
    
    // Calculate ability modifiers
    const strModifier = getAbilityModifier(strengthScore);
    const dexModifier = getAbilityModifier(dexterityScore);
    
    // Get selected chest armor for HP and AC calculations
    const selectedChestValue = document.getElementById('chest-select').value;
    let hitDice = "";
    let armorClassText = "";
    
    if (selectedChestValue) {
        const selectedChestArmor = armorData[selectedChestValue];
        hitDice = selectedChestArmor.hitdice;
        armorClassText = selectedChestArmor.armorclass;
        
        // Calculate and display HP and AC
        const maxHP = calculateMaxHP(hitDice, constitutionScore);
        const armorClass = calculateAC(armorClassText, dexterityScore);
        
        document.getElementById('hp-display').textContent = maxHP;
        document.getElementById('ac-display').textContent = armorClass;
    } else {
        document.getElementById('hp-display').textContent = "-";
        document.getElementById('ac-display').textContent = "-";
    }
      // Populate character information
    populateCharacterInfo();
    
    // Populate weapons information
    populateWeaponsInfo();
    
    // Populate results for each armor piece
    const armorTypes = ['helmet', 'pauldrons', 'chest', 'arms', 'boots', 'raiment'];
    
    // Track level 5 effects
    let level5Effects = [];
    
    armorTypes.forEach(type => {
        const selectElement = document.getElementById(`${type}-select`);
        const selectedValue = selectElement.value;
        
        const resultContainer = document.getElementById(`${type}-result`);
        const nameSpan = resultContainer.querySelector('.loadout-item-name');
        const progressionDiv = resultContainer.querySelector('.loadout-item-progression');
        
        // Get the image container for this armor piece
        const imageContainer = document.getElementById(`${type}-image`);
        
        if (selectedValue === "") {
            nameSpan.textContent = "None Selected";
            progressionDiv.innerHTML = "<p>No progression available.</p>";
            
            // Reset the image placeholder
            imageContainer.innerHTML = `<div class="armor-image-placeholder">${type.charAt(0).toUpperCase() + type.slice(1)}</div>`;
        } else {            const selectedArmor = armorData[selectedValue];
            nameSpan.textContent = selectedArmor.name;
            
            // Set armor image if available
            if (selectedArmor.imageUrl) {
                imageContainer.innerHTML = `<img src="${selectedArmor.imageUrl}" alt="${selectedArmor.name}">`;
            } else {
                imageContainer.innerHTML = `<div class="armor-image-placeholder">${selectedArmor.name}</div>`;
            }
            
            // Populate progression with enhanced descriptions
            let progressionHTML = `<p class="armor-description">${getEnhancedDescription(selectedArmor, type)}</p>`;
            
            // Add chest armor specific details (Hit Die and AC)
            if (type === 'chest') {
                const dexterityScore = document.getElementById('dexterity').value || 10;
                const constitutionScore = document.getElementById('constitution').value || 10;
                const dexModifier = getAbilityModifier(dexterityScore);
                const conModifier = getAbilityModifier(constitutionScore);
                
                const armorClass = calculateAC(selectedArmor.armorclass, dexterityScore);
                const maxHP = calculateMaxHP(selectedArmor.hitdice, constitutionScore);
                
                progressionHTML += `<div class="armor-stats">
                    <p><strong>Hit Die:</strong> ${selectedArmor.hitdice}</p>
                    <p><strong>Armor Class:</strong> ${selectedArmor.armorclass} (${armorClass} with DEX ${dexModifier >= 0 ? '+' : ''}${dexModifier})</p>
                    <p><strong>Max HP at Level 5:</strong> ${maxHP} (with CON ${conModifier >= 0 ? '+' : ''}${conModifier})</p>
                </div>`;
            }            
            progressionDiv.innerHTML = progressionHTML;
            
            // level 5 effects (assuming level 1 and 4 effects apply at level 5)
            if (selectedArmor.progression.length >= 2) {
                // first effect (level 1)
                const level1Effect = selectedArmor.progression[0];
                
                // second effect (level 4)
                const level4Effect = selectedArmor.progression[1];
                
                // to level 5 effects
                level5Effects.push({
                    name: selectedArmor.name,
                    type: type,
                    level1: extractEffectDescription(level1Effect),
                    level4: extractEffectDescription(level4Effect)
                });
            }
        }
    });
    
    // late the level 5 effects chart
    populateLevelEffectsChart(level5Effects);
}

// Function to get enhanced descriptions for the final loadout
function getEnhancedDescription(armor, type) {
    // c description
    let description = armor.description;
    
    // type-specific enhancements based on the reference document
    switch(type) {
        case 'helmet':
            if (armor.name === "Hypersensory Scanner Array") {
                description += " This advanced helmet provides darkvision (up to 60 ft.) if you lack it and lets you, once per short rest, briefly highlight hidden or invisible creatures.";
            }
            break;
        case 'pauldrons':
            if (armor.name === "Tech Type") {
                description += " The tech-pauldron grants proficiency with an extra tool and adds two extra 'robotic arms' that provide a +5 bonus to actions related to technical activities.";
            }
            break;
        case 'arms':
            if (armor.name === "Blastbreaker Fists") {
                description += " These allow you to wield two-handed weapons in one hand with no penalty and reclassify normally non-finesse light or one-handed weapons as finesse weapons for you.";
            } else if (armor.name === "Somatic Satellites") {
                description += " When paired with Tech Pauldron, the satellites integrate with the robotic arms, allowing you to cast additional non-cantrip spells in one turn.";
            }
            break;
        case 'chest':
            if (armor.name === "Balanced Type Composite Frame") {
                description += " Provides AC 14 + DEX (max +2) and grants a bonus to movement speed (+10 ft.) with a temporary +2 shield bonus to AC once per day.";
            } else if (armor.name === "Bulwark Type Frame") {
                description += " Provides base AC 16 and allows you to negate one chosen magical or physical damage type for 1 minute once per day.";
            } else if (armor.name === "Light Type Frame") {
                description += " Provides AC 13 + DEX and grants a static increase to movement speed (+15 ft.) with a temporary +1 shield bonus to AC while active.";
            }
            break;
        case 'boots':
            if (armor.name === "Blastcore Soles") {
                description += " Sets your base movement speed at 40 ft. and grants advantage on jump checks with a 10-ft running start. Once per short rest, leap over enemies without provoking opportunity attacks.";
            }
            break;
        case 'raiment':
            if (armor.name === "Soul Core Manifold") {
                description += " Grants two bonus Cell Charges and improves your recharge rate (restoring an extra half-hit-die's worth of charges per short rest).";
            } else if (armor.name === "Godhead Shard") {
                description += " Restores 2 Cell Charges per short rest if you pass a DC 14 Religion check, representing a brief prayer or rite.";
            } else if (armor.name === "Mystery Module") {
                description += " Whenever you activate a power, power surge, or expend a cell charge, you may choose to roll on the Wonder Module Miracore table for random effects.";
            }
            break;
    }
    
    return description;
}

// Function to populate character information in the loadout view
function populateCharacterInfo() {
    // character information from input fields
    const characterName = document.getElementById('character-name').value || "Unnamed Aegisknight";
    const characterRace = document.getElementById('character-race').value || "Unknown Race";
    const strength = document.getElementById('strength').value || "-";
    const dexterity = document.getElementById('dexterity').value || "-";
    const constitution = document.getElementById('constitution').value || "-";
    const intelligence = document.getElementById('intelligence').value || "-";
    const wisdom = document.getElementById('wisdom').value || "-";
    const charisma = document.getElementById('charisma').value || "-";
    const background = document.getElementById('background').value || "No background specified";
    const backgroundFeat = document.getElementById('background-feat').value || "No background feat specified";
    
    // appearance details
    const hairColor = document.getElementById('hair-color').value || "Not specified";
    const eyeColor = document.getElementById('eye-color').value || "Not specified";
    const skinColor = document.getElementById('skin-color').value || "Not specified";
    const notableFeatures = document.getElementById('notable-features').value || "None";
    
    // character name and race
    document.getElementById('character-name-display').textContent = characterName;
    document.getElementById('character-race-display').textContent = characterRace;
    
    // ability scores
    document.getElementById('strength-display').textContent = strength;
    document.getElementById('dexterity-display').textContent = dexterity;
    document.getElementById('constitution-display').textContent = constitution;
    document.getElementById('intelligence-display').textContent = intelligence;
    document.getElementById('wisdom-display').textContent = wisdom;
    document.getElementById('charisma-display').textContent = charisma;
    
    // appearance details
    document.getElementById('hair-display').textContent = hairColor;
    document.getElementById('eye-display').textContent = eyeColor;
    document.getElementById('skin-display').textContent = skinColor;
    document.getElementById('features-display').textContent = notableFeatures;
    
    // background information
    document.getElementById('background-display').textContent = background;
    document.getElementById('background-feat-display').textContent = backgroundFeat;
    
    // character feats
    populateCharacterFeats();
}

// Function to extract the description part from effect text
function extractEffectDescription(effectText) {
    // act the text after the level part (e.g., "<strong>Level 1:</strong> Some effect" -> "Some effect")
    const match = effectText.match(/<strong>Level \d+:<\/strong>\s*(.*)/);
    return match ? match[1] : effectText;
}

// Function to populate the level 5 effects chart
function populateLevelEffectsChart(effects) {
    const chartContainer = document.getElementById('level-effects-chart');
    
    if (effects.length === 0) {
        chartContainer.innerHTML = '<p class="no-effects">No effects available - select armor pieces to see their level 5 effects</p>';
        return;
    }
    
    let chartHTML = '';
    
    effects.forEach(effect => {
        chartHTML += `
            <div class="effect-item">
                <h4>${effect.name} (${effect.type.charAt(0).toUpperCase() + effect.type.slice(1)})</h4>
                <p><strong>Level 1:</strong> ${effect.level1}</p>
                <p><strong>Level 4:</strong> ${effect.level4}</p>
            </div>
        `;
    });
    
    chartContainer.innerHTML = chartHTML;
}

function backToSelection() {
    const selectorContainer = document.querySelector('.selector-container');
    const loadoutResults = document.getElementById('loadout-results');
    
    // Show selector, hide results
    selectorContainer.style.display = 'flex';
    loadoutResults.classList.add('hidden');
}

// Function to populate character feats in the loadout view
function populateCharacterFeats() {
    const featsDisplay = document.getElementById('character-feats-display');
    
    // Clear existing content
    featsDisplay.innerHTML = '';
    
    // If no feats are selected, show a message
    if (selectedFeats.length === 0) {
        featsDisplay.innerHTML = '<p class="no-feats">No feats selected</p>';
        return;
    }
    
    // t ASI feats
    const asiFeats = selectedFeats.filter(feat => feat.asi);
    
    // feat summary if there are any feats
    if (selectedFeats.length > 0) {
        const summaryElement = document.createElement('div');
        summaryElement.className = 'feats-summary';
        summaryElement.innerHTML = `
            <p>Total Feats: <strong>${selectedFeats.length}</strong> | 
            ASI Feats: <strong>${asiFeats.length}</strong> | 
            Other Feats: <strong>${selectedFeats.length - asiFeats.length}</strong></p>
        `;
        featsDisplay.appendChild(summaryElement);
    }
    
    // Create a card for each selected feat
    selectedFeats.forEach(feat => {
        const featCard = document.createElement('div');
        featCard.className = 'feat-card';
        if (feat.asi) featCard.classList.add('asi-feat');
        
        featCard.innerHTML = `
            <h4>${feat.name} ${feat.asi ? "(ASI)" : ""}</h4>
            <p>${feat.description}</p>
        `;
        featsDisplay.appendChild(featCard);
    });
}

// Add keyboard shortcut for adding feats
function initKeyboardShortcuts() {
    // Add keyboard shortcut (Enter) for adding feats when the dropdown is focused
    const featsSelect = document.getElementById('feats-select');
    if (featsSelect) {
        featsSelect.addEventListener('keydown', function(event) {
            if (event.key === 'Enter') {
                addSelectedFeat();
                event.preventDefault();
            }
        });
    }
    
    // Add keyboard shortcut (Enter) for the feat search field to focus the dropdown
    const featSearch = document.getElementById('feat-search');
    if (featSearch) {
        featSearch.addEventListener('keydown', function(event) {
            if (event.key === 'Enter') {
                featsSelect.focus();
                event.preventDefault();
            }
        });
    }
}

// Add selected feat to the list
function addSelectedFeat() {
    const featsSelect = document.getElementById('feats-select');
    const selectedFeatId = featsSelect.value;
    
    if (!selectedFeatId) {
        // No feat selected, show a tooltip or message if you have UI for that
        return;
    }
    
    // Check if feat is already selected
    if (selectedFeats.some(feat => feat.id === selectedFeatId)) {
        // Show feedback - you could create a nicer toast notification
        const featPreview = document.getElementById('feat-preview');
        const originalContent = featPreview.innerHTML;
        
        featPreview.innerHTML = '<p class="error-message">This feat is already selected!</p>';
        featPreview.classList.add('active', 'error');
        
        // Reset after a short delay
        setTimeout(() => {
            featPreview.innerHTML = originalContent;
            featPreview.classList.remove('error');
        }, 2000);
        
        return;
    }
    
    // Find the feat in the data
    const feat = featsData.find(feat => feat.id === selectedFeatId);
    if (feat) {
        // Add to selectedFeats array
        selectedFeats.push(feat);
        
        // Update the UI
        updateSelectedFeatsUI();
        
        // Show success message in preview
        const featPreview = document.getElementById('feat-preview');
        const originalContent = featPreview.innerHTML;
        
        featPreview.innerHTML = '<p class="success-message">Feat added successfully!</p>';
        featPreview.classList.add('active', 'success');
        
        // eset after a short delay
        setTimeout(() => {
            // eset dropdown
            featsSelect.value = '';
            featPreview.innerHTML = '';
            featPreview.classList.remove('active', 'success');
        }, 1000);
    }
}

// pdate the selected feats UI
function updateSelectedFeatsUI() {
    const selectedFeatsContainer = document.getElementById('selected-feats-container');
    const featsCountBadge = document.getElementById('feats-count');
    
    // pdate count badge
    if (featsCountBadge) {
        featsCountBadge.textContent = selectedFeats.length;
    }
    
    // lear current content
    selectedFeatsContainer.innerHTML = '';
    
    // o feats selected
    if (selectedFeats.length === 0) {
        selectedFeatsContainer.innerHTML = '<div class="no-feats">No feats selected</div>';
        return;
    }
    
    // dd each selected feat
    selectedFeats.forEach((feat, index) => {
        const featElement = document.createElement('div');
        featElement.className = 'selected-feat';
        featElement.setAttribute('data-tooltip', feat.description);
        featElement.innerHTML = `
            <div class="feat-name">${feat.name}</div>
            <button type="button" class="remove-feat" data-index="${index}" aria-label="Remove ${feat.name}">×</button>
        `;
        selectedFeatsContainer.appendChild(featElement);
    });
    
    // Add event listeners to remove buttons
    const removeButtons = selectedFeatsContainer.querySelectorAll('.remove-feat');
    removeButtons.forEach(button => {
        button.addEventListener('click', function() {
            const index = parseInt(this.getAttribute('data-index'));
            removeSelectedFeat(index);
        });
    });
}

// Remove a selected feat
function removeSelectedFeat(index) {
    selectedFeats.splice(index, 1);
    updateSelectedFeatsUI();
}

// Initialize feat-related UI elements
function initFeatsUI() {
    const addFeatButton = document.getElementById('add-feat-button');
    const featSearch = document.getElementById('feat-search');
    const asiFilter = document.getElementById('asi-filter');
    
    // Add feat button click event
    if (addFeatButton) {
        addFeatButton.addEventListener('click', addSelectedFeat);
    }
    
    // Search input event
    if (featSearch) {
        featSearch.addEventListener('input', function() {
            populateFeatsDropdown(this.value);
        });
    }
    
    // ASI filter change event
    if (asiFilter) {
        asiFilter.addEventListener('change', function() {
            populateFeatsDropdown(featSearch ? featSearch.value : '');
        });
    }
    
    // Initialize keyboard shortcuts
    initKeyboardShortcuts();
    
    // Update selected feats UI on initial load
    updateSelectedFeatsUI();
}

// Function to preview the selected feat before adding
function previewFeat() {
    const featsSelect = document.getElementById('feats-select');
    const featPreview = document.getElementById('feat-preview');
    
    const selectedFeatId = featsSelect.value;
    
    if (!selectedFeatId) {
        featPreview.innerHTML = '';
        featPreview.classList.remove('active');
        return;
    }
    
    const feat = featsData.find(feat => feat.id === selectedFeatId);
    if (feat) {
        featPreview.innerHTML = `
            <h4>${feat.name} ${feat.asi ? "(ASI)" : ""}</h4>
            <p>${feat.description}</p>
        `;
        featPreview.classList.add('active');
    }
}

// Function to calculate ability score modifier
function getAbilityModifier(score) {
    if (!score || isNaN(parseInt(score))) return 0;
    return Math.floor((parseInt(score) - 10) / 2);
}

// Function to calculate max HP for level 5
function calculateMaxHP(hitDice, constitutionScore) {
    if (!hitDice) return "-";
    
    const conModifier = getAbilityModifier(constitutionScore);
    let baseHP = 0;
    
    // Calculate HP based on hit dice
    switch(hitDice) {
        case "d8":
            baseHP = 8 + (8 * 4); // Maximized HP
            break;
        case "d10":
            baseHP = 10 + (10 * 4); // Maximized HP
            break;
        case "d12":
            baseHP = 12 + (12 * 4); // Maximized HP
            break;
        default:
            return "-";
    }
    
    // Add Con modifier for all 5 levels
    return baseHP + (conModifier * 5);
}

// Function to calculate AC
function calculateAC(armorClassText, dexterityScore) {
    if (!armorClassText) return "-";
    
    const dexModifier = getAbilityModifier(dexterityScore);
    
    // If AC is a flat value like "17"
    if (!isNaN(parseInt(armorClassText))) {
        return parseInt(armorClassText);
    }
    
    // If AC includes Dex modifier
    if (armorClassText.includes("Dex modifier")) {
        const baseAC = parseInt(armorClassText.match(/\d+/)[0]);
        
        // Check if there's a max cap on Dex modifier
        if (armorClassText.includes("max")) {
            const maxDexBonus = parseInt(armorClassText.match(/max \+(\d+)/)[1]);
            return baseAC + Math.min(dexModifier, maxDexBonus);
        } else {
            return baseAC + dexModifier;
        }
    }
    
    return "-";
}

// Add event listeners to update HP and AC when ability scores or chest armor change
document.addEventListener('DOMContentLoaded', function() {
    // Elements that affect HP and AC calculations
    const dexInput = document.getElementById('dexterity');
    const conInput = document.getElementById('constitution');
    const chestSelect = document.getElementById('chest-select');
    
    // Function to update the preview if viewing chest armor
    const updateStatsDisplay = function() {
        const currentArmorType = document.getElementById('chest-select');
        if (currentArmorType && currentArmorType.value) {
            updateArmorInfo('chest');
        }
    };
    
    // Add event listeners
    if (dexInput) dexInput.addEventListener('change', updateStatsDisplay);
    if (conInput) conInput.addEventListener('change', updateStatsDisplay);
    if (chestSelect) chestSelect.addEventListener('change', updateStatsDisplay);
});

// Function to populate weapon dropdowns
function populateWeaponDropdowns() {
    const primarySelect = document.getElementById('primary-weapon-select');
    const secondarySelect = document.getElementById('secondary-weapon-select');
    
    // Clear existing options except the first one
    while (primarySelect.options.length > 1) {
        primarySelect.remove(1);
    }
    
    while (secondarySelect.options.length > 1) {
        secondarySelect.remove(1);
    }
    
    // Add weapons to dropdowns
    weaponsData.forEach(weapon => {
        // Create options for primary weapon
        const primaryOption = document.createElement('option');
        primaryOption.value = weapon.id;
        primaryOption.textContent = `${weapon.name} (${weapon.damage_dice} ${weapon.damage_type})`;
        primarySelect.appendChild(primaryOption);
        
        // Create options for secondary weapon
        const secondaryOption = document.createElement('option');
        secondaryOption.value = weapon.id;
        secondaryOption.textContent = `${weapon.name} (${weapon.damage_dice} ${weapon.damage_type})`;
        secondarySelect.appendChild(secondaryOption);
    });
}

// Function to update weapon info display
function updateWeaponInfo(weaponType) {
    const selectId = `${weaponType}-weapon-select`;
    const selectElement = document.getElementById(selectId);
    const selectedValue = selectElement.value;
    
    // Find the description area to update
    const nameElement = document.getElementById('selected-item-name');
    const descriptionElement = document.getElementById('selected-item-description');
    
    if (selectedValue === "") {
        // No weapon is selected, we'll just leave the current armor info
        return;
    }
    
    // Find the selected weapon data
    const selectedWeapon = weaponsData.find(weapon => weapon.id === selectedValue);
    
    if (!selectedWeapon) return;
    
    // Update the info panel
    nameElement.textContent = selectedWeapon.name;
    
    // Check the large size checkbox status
    const isLargeSize = document.getElementById(`${weaponType}-large-size`).checked;
    
    // Calculate damage based on size
    let damageDisplay = selectedWeapon.damage_dice;
    if (isLargeSize) {
        // Double the number of dice for large size weapons
        damageDisplay = doubleDamageDice(selectedWeapon.damage_dice);
    }
    
    // Create weapon details
    let weaponDescription = `
        <div class="weapon-info">
            <p><strong>Damage:</strong> ${damageDisplay} ${selectedWeapon.damage_type}</p>
            <p><strong>Category:</strong> ${selectedWeapon.category}</p>
            <p><strong>Properties:</strong> ${selectedWeapon.special}</p>
            ${isLargeSize ? '<p><strong>Large Size:</strong> This weapon is being wielded as a large-sized weapon, doubling its damage dice.</p>' : ''}
        </div>
    `;
    
    descriptionElement.innerHTML = weaponDescription;
}

// Function to double damage dice for large weapons
function doubleDamageDice(damageDice) {
    // Parse the damage dice format (e.g., "1d8", "2d6", etc.)
    const match = damageDice.match(/(\d+)d(\d+)/);
    if (!match) return damageDice; // Return original if format doesn't match
    
    const numberOfDice = parseInt(match[1]);
    const diceType = match[2];
    
    // Double the number of dice
    return `${numberOfDice * 2}d${diceType}`;
}

// Function to populate weapons in the loadout view
function populateWeaponsInfo() {
    // Process primary weapon
    const primaryWeaponId = document.getElementById('primary-weapon-select').value;
    const primaryLargeSize = document.getElementById('primary-large-size').checked;
    
    // Process secondary weapon
    const secondaryWeaponId = document.getElementById('secondary-weapon-select').value;
    const secondaryLargeSize = document.getElementById('secondary-large-size').checked;
    
    // Get the strength and dexterity modifiers for attack bonuses
    const strengthScore = document.getElementById('strength').value || 10;
    const dexterityScore = document.getElementById('dexterity').value || 10;
    const strModifier = getAbilityModifier(strengthScore);
    const dexModifier = getAbilityModifier(dexterityScore);
    
    // Populate primary weapon info
    const primaryNameElement = document.getElementById('primary-weapon-name');
    const primaryDamageElement = document.getElementById('primary-weapon-damage');
    const primaryTypeElement = document.getElementById('primary-weapon-type');
    const primaryPropertiesElement = document.getElementById('primary-weapon-properties');
    
    if (primaryWeaponId) {
        const primaryWeapon = weaponsData.find(weapon => weapon.id === primaryWeaponId);
        if (primaryWeapon) {
            primaryNameElement.textContent = primaryWeapon.name;
            
            // Calculate damage based on size
            let damageDisplay = primaryWeapon.damage_dice;
            if (primaryLargeSize) {
                damageDisplay = doubleDamageDice(primaryWeapon.damage_dice);
            }
            
            // Add appropriate ability modifier to damage
            const usesDex = primaryWeapon.special && primaryWeapon.special.toLowerCase().includes('finesse');
            const bestModifier = usesDex ? Math.max(strModifier, dexModifier) : strModifier;
            const modifierDisplay = bestModifier >= 0 ? `+${bestModifier}` : bestModifier;
            
            primaryDamageElement.textContent = `${damageDisplay} ${modifierDisplay} ${primaryWeapon.damage_type}`;
            primaryTypeElement.textContent = primaryWeapon.category;
            primaryPropertiesElement.textContent = primaryWeapon.special || "None";
        }
    } else {
        primaryNameElement.textContent = "None Selected";
        primaryDamageElement.textContent = "-";
        primaryTypeElement.textContent = "-";
        primaryPropertiesElement.textContent = "-";
    }
    
    // Populate secondary weapon info
    const secondaryNameElement = document.getElementById('secondary-weapon-name');
    const secondaryDamageElement = document.getElementById('secondary-weapon-damage');
    const secondaryTypeElement = document.getElementById('secondary-weapon-type');
    const secondaryPropertiesElement = document.getElementById('secondary-weapon-properties');
    
    if (secondaryWeaponId) {
        const secondaryWeapon = weaponsData.find(weapon => weapon.id === secondaryWeaponId);
        if (secondaryWeapon) {
            secondaryNameElement.textContent = secondaryWeapon.name;
            
            // Calculate damage based on size
            let damageDisplay = secondaryWeapon.damage_dice;
            if (secondaryLargeSize) {
                damageDisplay = doubleDamageDice(secondaryWeapon.damage_dice);
            }
            
            // Add appropriate ability modifier to damage
            const usesDex = secondaryWeapon.special && secondaryWeapon.special.toLowerCase().includes('finesse');
            const bestModifier = usesDex ? Math.max(strModifier, dexModifier) : strModifier;
            const modifierDisplay = bestModifier >= 0 ? `+${bestModifier}` : bestModifier;
            
            secondaryDamageElement.textContent = `${damageDisplay} ${modifierDisplay} ${secondaryWeapon.damage_type}`;
            secondaryTypeElement.textContent = secondaryWeapon.category;
            secondaryPropertiesElement.textContent = secondaryWeapon.special || "None";
        }
    } else {
        secondaryNameElement.textContent = "None Selected";
        secondaryDamageElement.textContent = "-";
        secondaryTypeElement.textContent = "-";
        secondaryPropertiesElement.textContent = "-";
    }
}
